# Flight Management System - Microservices Backend

## Architecture Overview

```
Client (Postman / Frontend)
         |
    [API Gateway :8080]  ← JWT Validation, Load Balancing, Routing
    /     |      |     \
[User] [Flight] [Booking] [Payment]
:8081  :8082    :8083      :8084
         ↑
  [Eureka Server :8761]  ← Service Registry & Discovery

  [RabbitMQ :5672]  ← Booking/Payment Event Messaging
  [MySQL]  ← 4 separate databases
```

## Microservices

| Service | Port | Database | Description |
|---|---|---|---|
| Eureka Server | 8761 | - | Service Discovery |
| API Gateway | 8080 | - | Routing + JWT Auth |
| User Service | 8081 | flight_user_db | Registration, Login, JWT |
| Flight Service | 8082 | flight_flight_db | Flights, Search, Fare |
| Booking Service | 8083 | flight_booking_db | Bookings, Check-in |
| Payment Service | 8084 | flight_payment_db | Payments, Refunds |

---

## Prerequisites

- Java 17+
- Maven 3.8+
- MySQL 8+
- RabbitMQ 3.x (optional but needed for messaging)

---

## Setup & Run

### Step 1: Database Setup
```sql
mysql -u root -p < db-init.sql
```

### Step 2: Start RabbitMQ (optional)
```bash
# With Docker:
docker run -d --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3-management
```

### Step 3: Start Services IN ORDER

```bash
# 1. Eureka Server (start first)
cd eureka-server && mvn spring-boot:run

# 2. API Gateway
cd api-gateway && mvn spring-boot:run

# 3. User Service
cd user-service && mvn spring-boot:run

# 4. Flight Service
cd flight-service && mvn spring-boot:run

# 5. Booking Service
cd booking-service && mvn spring-boot:run

# 6. Payment Service
cd payment-service && mvn spring-boot:run
```

---

## Eureka Dashboard
Open: http://localhost:8761

All 4 microservices should appear as registered instances.

---

## Swagger API Docs (per service)
- User Service:    http://localhost:8081/swagger-ui/index.html
- Flight Service:  http://localhost:8082/swagger-ui/index.html
- Booking Service: http://localhost:8083/swagger-ui/index.html
- Payment Service: http://localhost:8084/swagger-ui/index.html

---

## Postman Testing Guide

### All requests go through API Gateway on port 8080.

---

### 1. Register User (No Auth)
```
POST http://localhost:8080/api/users/register
Content-Type: application/json

{
  "firstName": "Joe",
  "lastName": "Traveller",
  "email": "joe@example.com",
  "password": "password123",
  "phoneNumber": "9876543210",
  "role": "PASSENGER"
}
```
Response: `{ "token": "eyJ...", "userId": 1, "email": "joe@example.com", "role": "PASSENGER" }`

---

### 2. Login (No Auth)
```
POST http://localhost:8080/api/users/login
Content-Type: application/json

{
  "email": "joe@example.com",
  "password": "password123"
}
```
**Copy the `token` from response. Use it as Bearer token for all subsequent requests.**

---

### 3. Login as Admin
```
POST http://localhost:8080/api/users/login
{
  "email": "admin@flightms.com",
  "password": "admin123"
}
```

---

### 4. Search Flights (Requires Auth)
```
GET http://localhost:8080/api/flights?source=Mumbai&destination=Delhi&travelDate=2025-12-25
Authorization: Bearer <token>
```

---

### 5. Get All Flights
```
GET http://localhost:8080/api/flights/all
Authorization: Bearer <token>
```

---

### 6. Create Flight (Admin Only)
```
POST http://localhost:8080/api/admin/flights
Authorization: Bearer <admin-token>
Content-Type: application/json

{
  "flightNumber": "AI999",
  "airlineName": "Air India",
  "source": "Mumbai",
  "destination": "Pune",
  "departureTime": "2025-12-26T08:00:00",
  "arrivalTime": "2025-12-26T09:00:00",
  "travelDate": "2025-12-26",
  "totalSeats": 100,
  "baseFare": 1500.00
}
```

---

### 7. Create Booking (Requires Auth)
```
POST http://localhost:8080/api/bookings
Authorization: Bearer <token>
Content-Type: application/json

{
  "userId": 1,
  "flightId": 1,
  "passengerName": "Joe Traveller",
  "passengerEmail": "joe@example.com",
  "passengerPhone": "9876543210",
  "idProofNumber": "ABCDE1234F"
}
```
Response: `{ "bookingId": 1, "bookingReference": "REF12345", "status": "PENDING", ... }`

---

### 8. Initiate Payment (Requires Auth)
```
POST http://localhost:8080/api/payments
Authorization: Bearer <token>
Content-Type: application/json

{
  "bookingId": 1,
  "userId": 1,
  "amount": 3500.00,
  "paymentMethod": "UPI"
}
```
Response: `{ "paymentId": 1, "transactionId": "TXN...", "status": "INITIATED" }`

---

### 9. Process Payment (Requires Auth)
```
POST http://localhost:8080/api/payments/process
Authorization: Bearer <token>
Content-Type: application/json

{
  "paymentId": 1,
  "paymentToken": "VALID_TOKEN",
  "upiId": "joe@upi"
}
```
- Use `"paymentToken": "FAIL_TEST"` to force a payment failure.
- On SUCCESS: Booking is automatically CONFIRMED via inter-service call.
- On FAILURE: Booking is automatically CANCELLED via inter-service call.

---

### 10. Check Booking Status
```
GET http://localhost:8080/api/bookings/1
Authorization: Bearer <token>
```

---

### 11. Check-In (Booking must be CONFIRMED)
```
POST http://localhost:8080/api/bookings/checkin
Authorization: Bearer <token>
Content-Type: application/json

{
  "bookingId": 1,
  "bookingReference": "REF12345"
}
```
Response: `{ "boardingPassNumber": "BP12345", "seatNumber": "12A", ... }`

---

### 12. Get All User Bookings
```
GET http://localhost:8080/api/bookings/user/1
Authorization: Bearer <token>
```

---

### 13. Cancel Booking
```
PUT http://localhost:8080/api/bookings/1/cancel
Authorization: Bearer <token>
```

---

### 14. Refund Payment
```
POST http://localhost:8080/api/payments/refund
Authorization: Bearer <token>
Content-Type: application/json

{
  "paymentId": 1,
  "reason": "Cancelled booking"
}
```

---

## Running Unit Tests

```bash
# Run tests for all services
cd user-service    && mvn test
cd flight-service  && mvn test
cd booking-service && mvn test
cd payment-service && mvn test
```

---

## JWT Secret
All services share the same secret (Base64-encoded):
```
ZmxpZ2h0bWFuYWdlbWVudHN5c3RlbXNlY3JldGtleWZvcmphdmFzcHJpbmcyMDI0
```
Decoded: `flightmanagementsystemsecretkeyforrjavaspring2024`

---

## Key Design Decisions

- **Layered Architecture**: Controller → Service → Repository per microservice
- **JWT**: Shared secret across all services; Gateway validates, downstream services trust
- **Feign + Eureka**: Load-balanced inter-service HTTP calls (Booking→Flight, Payment→Booking)
- **RabbitMQ**: Booking/Payment events published asynchronously (booking.exchange)
- **Dynamic Pricing**: Fare surcharge applied based on seat occupancy (50%→15%, 80%→30%)
- **Global Exception Handling**: Uniform error response format across all services
- **SLF4J Logging**: All service/controller layers use structured logging
- **Data Validation**: Bean Validation (@NotBlank, @Email, @Pattern, etc.) on all DTOs
- **Mockito Tests**: Service layer and controller layer tests in all 4 microservices
