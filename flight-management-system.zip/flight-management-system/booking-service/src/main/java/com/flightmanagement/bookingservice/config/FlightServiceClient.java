package com.flightmanagement.bookingservice.config;

import com.flightmanagement.bookingservice.dto.FlightResponseDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

/**
 * Feign client for inter-service communication with Flight Service.
 * Registered via Eureka - no hardcoded URLs.
 */
@FeignClient(name = "flight-service")
public interface FlightServiceClient {

    /**
     * Gets flight details from Flight Service by ID.
     */
    @GetMapping("/api/flights/{flightId}")
    FlightResponseDto getFlightById(@PathVariable("flightId") Long flightId);

    /**
     * Decrements available seats when a booking is confirmed.
     */
    @PutMapping("/api/flights/{flightId}/decrement-seats")
    void decrementSeats(@PathVariable("flightId") Long flightId);

    /**
     * Increments available seats when a booking is cancelled.
     */
    @PutMapping("/api/flights/{flightId}/increment-seats")
    void incrementSeats(@PathVariable("flightId") Long flightId);
}
