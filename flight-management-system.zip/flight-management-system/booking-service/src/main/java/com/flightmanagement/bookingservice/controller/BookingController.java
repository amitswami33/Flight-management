package com.flightmanagement.bookingservice.controller;

import com.flightmanagement.bookingservice.dto.BookingDto;
import com.flightmanagement.bookingservice.service.BookingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for Booking Management.
 * Exposes endpoints for booking creation, management, and check-in.
 */
@RestController
@RequestMapping("/api/bookings")
@Tag(name = "Booking Management", description = "APIs for flight bookings and check-in")
public class BookingController {

    private static final Logger logger = LoggerFactory.getLogger(BookingController.class);

    @Autowired
    private BookingService bookingService;

    /**
     * Creates a new booking.
     * POST /api/bookings
     */
    @PostMapping
    @Operation(summary = "Create a new booking", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<BookingDto.BookingResponse> createBooking(
            @Valid @RequestBody BookingDto.CreateBookingRequest request) {
        logger.info("Creating booking for user: {}", request.getUserId());
        BookingDto.BookingResponse response = bookingService.createBooking(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Gets a booking by ID.
     * GET /api/bookings/{bookingId}
     */
    @GetMapping("/{bookingId}")
    @Operation(summary = "Get booking by ID", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<BookingDto.BookingResponse> getBookingById(@PathVariable Long bookingId) {
        return ResponseEntity.ok(bookingService.getBookingById(bookingId));
    }

    /**
     * Gets all bookings for a specific user.
     * GET /api/bookings/user/{userId}
     */
    @GetMapping("/user/{userId}")
    @Operation(summary = "Get all bookings for a user", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<List<BookingDto.BookingResponse>> getBookingsByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(bookingService.getBookingsByUserId(userId));
    }

    /**
     * Gets booking by reference number.
     * GET /api/bookings/reference/{reference}
     */
    @GetMapping("/reference/{reference}")
    @Operation(summary = "Get booking by reference number", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<BookingDto.BookingResponse> getBookingByReference(@PathVariable String reference) {
        return ResponseEntity.ok(bookingService.getBookingByReference(reference));
    }

    /**
     * Confirms a booking (typically called after successful payment).
     * PUT /api/bookings/{bookingId}/confirm
     */
    @PutMapping("/{bookingId}/confirm")
    @Operation(summary = "Confirm booking after payment", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<BookingDto.BookingResponse> confirmBooking(@PathVariable Long bookingId) {
        logger.info("Confirming booking: {}", bookingId);
        return ResponseEntity.ok(bookingService.confirmBooking(bookingId));
    }

    /**
     * Cancels a booking.
     * PUT /api/bookings/{bookingId}/cancel
     */
    @PutMapping("/{bookingId}/cancel")
    @Operation(summary = "Cancel a booking", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<BookingDto.BookingResponse> cancelBooking(@PathVariable Long bookingId) {
        logger.info("Cancelling booking: {}", bookingId);
        return ResponseEntity.ok(bookingService.cancelBooking(bookingId));
    }

    /**
     * Performs check-in for a booking.
     * POST /api/bookings/checkin
     */
    @PostMapping("/checkin")
    @Operation(summary = "Perform check-in", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<BookingDto.CheckInResponse> performCheckIn(
            @Valid @RequestBody BookingDto.CheckInRequest request) {
        logger.info("Check-in request for reference: {}", request.getBookingReference());
        return ResponseEntity.ok(bookingService.performCheckIn(request));
    }
}
