package com.flightmanagement.bookingservice.dto;

import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Data Transfer Objects for Booking Service API communication.
 */
public class BookingDto {

    /**
     * DTO for creating a new booking.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateBookingRequest {

        @NotNull(message = "User ID is required")
        private Long userId;

        @NotNull(message = "Flight ID is required")
        private Long flightId;

        @NotBlank(message = "Passenger name is required")
        @Size(max = 100)
        private String passengerName;

        @NotBlank(message = "Passenger email is required")
        @Email(message = "Must be a valid email")
        private String passengerEmail;

        @NotBlank(message = "Passenger phone is required")
        @Pattern(regexp = "^[6-9]\\d{9}$", message = "Must be a valid 10-digit Indian mobile number")
        private String passengerPhone;

        @NotBlank(message = "ID proof number is required")
        private String idProofNumber;
    }

    /**
     * DTO returned after booking creation.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BookingResponse {
        private Long bookingId;
        private Long userId;
        private Long flightId;
        private String passengerName;
        private String passengerEmail;
        private String passengerPhone;
        private BigDecimal totalFare;
        private String status;
        private String bookingReference;
        private String seatNumber;
        private LocalDateTime bookingTime;
        private boolean checkInStatus;
        private LocalDateTime checkInTime;
        private String boardingPassNumber;
    }

    /**
     * DTO for check-in request.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CheckInRequest {

        @NotNull(message = "Booking ID is required")
        private Long bookingId;

        @NotBlank(message = "Booking reference is required")
        private String bookingReference;
    }

    /**
     * DTO for check-in response including boarding pass.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CheckInResponse {
        private Long bookingId;
        private String bookingReference;
        private String passengerName;
        private String boardingPassNumber;
        private String seatNumber;
        private LocalDateTime checkInTime;
        private String message;
    }
}
