package com.flightmanagement.bookingservice.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * DTO for receiving flight data from Flight Service via Feign client.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FlightResponseDto {
    private Long flightId;
    private String flightNumber;
    private String airlineName;
    private String source;
    private String destination;
    private LocalDateTime departureTime;
    private LocalDateTime arrivalTime;
    private LocalDate travelDate;
    private Integer totalSeats;
    private Integer availableSeats;
    private BigDecimal baseFare;
    private BigDecimal calculatedFare;
    private String status;
    private Integer durationMinutes;
}
