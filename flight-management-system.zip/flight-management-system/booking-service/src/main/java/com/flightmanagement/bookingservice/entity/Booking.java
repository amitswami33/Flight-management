package com.flightmanagement.bookingservice.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Booking entity representing a flight booking in the system.
 * Maps to the 'bookings' table in MySQL database.
 */
@Entity
@Table(name = "bookings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "booking_id")
    private Long bookingId;

    @NotNull(message = "User ID is required")
    @Column(name = "user_id", nullable = false)
    private Long userId;

    @NotNull(message = "Flight ID is required")
    @Column(name = "flight_id", nullable = false)
    private Long flightId;

    @NotBlank(message = "Passenger name is required")
    @Size(max = 100)
    @Column(name = "passenger_name", nullable = false, length = 100)
    private String passengerName;

    @NotBlank(message = "Passenger email is required")
    @Email(message = "Passenger email must be valid")
    @Column(name = "passenger_email", nullable = false, length = 100)
    private String passengerEmail;

    @NotBlank(message = "Passenger phone is required")
    @Column(name = "passenger_phone", nullable = false, length = 15)
    private String passengerPhone;

    @NotBlank(message = "Passport or Aadhaar number is required")
    @Column(name = "id_proof_number", nullable = false, length = 30)
    private String idProofNumber;

    @NotNull(message = "Total fare is required")
    @DecimalMin(value = "0.0", inclusive = false)
    @Column(name = "total_fare", nullable = false, precision = 10, scale = 2)
    private BigDecimal totalFare;

    @Enumerated(EnumType.STRING)
    @Column(name = "status", nullable = false, length = 20)
    private BookingStatus status = BookingStatus.PENDING;

    @Column(name = "booking_reference", unique = true, length = 12)
    private String bookingReference;

    @Column(name = "seat_number", length = 10)
    private String seatNumber;

    @Column(name = "booking_time")
    private LocalDateTime bookingTime;

    @Column(name = "check_in_status")
    private boolean checkInStatus = false;

    @Column(name = "check_in_time")
    private LocalDateTime checkInTime;

    @Column(name = "boarding_pass_number", length = 20)
    private String boardingPassNumber;

    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
        bookingTime = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    /**
     * Enum for possible booking statuses.
     */
    public enum BookingStatus {
        PENDING,        // Booking created, awaiting payment
        CONFIRMED,      // Payment successful
        CANCELLED,      // Booking cancelled
        CHECKED_IN      // Passenger has checked in
    }
}
