package com.flightmanagement.bookingservice.messaging;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Event DTO published to RabbitMQ for booking lifecycle events.
 * Consumed by notification or other downstream services.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BookingEvent {

    private String eventType;          // BOOKING_CONFIRMED, BOOKING_CANCELLED, CHECKED_IN
    private Long bookingId;
    private String bookingReference;
    private Long userId;
    private Long flightId;
    private String passengerName;
    private String passengerEmail;
    private String passengerPhone;
    private BigDecimal totalFare;
    private String status;
    private String seatNumber;
    private String boardingPassNumber;
    private LocalDateTime eventTime;
}
