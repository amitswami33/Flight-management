package com.flightmanagement.bookingservice.messaging;

import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ configuration for Booking Service.
 * Sets up exchange, queue and binding for booking event notifications.
 * Messages are published when booking is confirmed, cancelled, or check-in occurs.
 */
@Configuration
public class RabbitMQConfig {

    // Exchange names
    public static final String BOOKING_EXCHANGE = "booking.exchange";
    public static final String NOTIFICATION_EXCHANGE = "notification.exchange";

    // Queue names
    public static final String BOOKING_CONFIRMED_QUEUE = "booking.confirmed.queue";
    public static final String BOOKING_CANCELLED_QUEUE = "booking.cancelled.queue";
    public static final String CHECKIN_QUEUE = "checkin.queue";

    // Routing keys
    public static final String BOOKING_CONFIRMED_KEY = "booking.confirmed";
    public static final String BOOKING_CANCELLED_KEY = "booking.cancelled";
    public static final String CHECKIN_KEY = "booking.checkin";

    /**
     * Main booking topic exchange - routes messages by routing key pattern.
     */
    @Bean
    public TopicExchange bookingExchange() {
        return new TopicExchange(BOOKING_EXCHANGE);
    }

    /**
     * Notification exchange for sending email/SMS alerts.
     */
    @Bean
    public TopicExchange notificationExchange() {
        return new TopicExchange(NOTIFICATION_EXCHANGE);
    }

    /**
     * Queue for confirmed booking events.
     */
    @Bean
    public Queue bookingConfirmedQueue() {
        return QueueBuilder.durable(BOOKING_CONFIRMED_QUEUE).build();
    }

    /**
     * Queue for cancelled booking events.
     */
    @Bean
    public Queue bookingCancelledQueue() {
        return QueueBuilder.durable(BOOKING_CANCELLED_QUEUE).build();
    }

    /**
     * Queue for check-in events.
     */
    @Bean
    public Queue checkInQueue() {
        return QueueBuilder.durable(CHECKIN_QUEUE).build();
    }

    @Bean
    public Binding bookingConfirmedBinding() {
        return BindingBuilder.bind(bookingConfirmedQueue())
                .to(bookingExchange())
                .with(BOOKING_CONFIRMED_KEY);
    }

    @Bean
    public Binding bookingCancelledBinding() {
        return BindingBuilder.bind(bookingCancelledQueue())
                .to(bookingExchange())
                .with(BOOKING_CANCELLED_KEY);
    }

    @Bean
    public Binding checkInBinding() {
        return BindingBuilder.bind(checkInQueue())
                .to(bookingExchange())
                .with(CHECKIN_KEY);
    }

    /**
     * JSON message converter for serializing POJOs to/from JSON.
     */
    @Bean
    public Jackson2JsonMessageConverter messageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    /**
     * RabbitTemplate configured with JSON converter.
     */
    @Bean
    public RabbitTemplate rabbitTemplate(ConnectionFactory connectionFactory) {
        RabbitTemplate template = new RabbitTemplate(connectionFactory);
        template.setMessageConverter(messageConverter());
        return template;
    }
}
