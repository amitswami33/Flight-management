package com.flightmanagement.bookingservice.repository;

import com.flightmanagement.bookingservice.entity.Booking;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * JPA Repository for Booking entity.
 */
@Repository
public interface BookingRepository extends JpaRepository<Booking, Long> {

    /**
     * Finds all bookings by user ID.
     */
    List<Booking> findByUserId(Long userId);

    /**
     * Finds all bookings for a specific flight.
     */
    List<Booking> findByFlightId(Long flightId);

    /**
     * Finds a booking by its unique reference number.
     */
    Optional<Booking> findByBookingReference(String bookingReference);

    /**
     * Checks if a booking reference already exists.
     */
    boolean existsByBookingReference(String bookingReference);

    /**
     * Finds all bookings with a given status.
     */
    List<Booking> findByStatus(Booking.BookingStatus status);
}
