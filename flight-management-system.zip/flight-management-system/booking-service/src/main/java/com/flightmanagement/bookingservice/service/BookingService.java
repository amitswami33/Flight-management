package com.flightmanagement.bookingservice.service;

import com.flightmanagement.bookingservice.config.FlightServiceClient;
import com.flightmanagement.bookingservice.dto.BookingDto;
import com.flightmanagement.bookingservice.dto.FlightResponseDto;
import com.flightmanagement.bookingservice.entity.Booking;
import com.flightmanagement.bookingservice.exception.BookingNotFoundException;
import com.flightmanagement.bookingservice.messaging.BookingEvent;
import com.flightmanagement.bookingservice.messaging.RabbitMQConfig;
import com.flightmanagement.bookingservice.repository.BookingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Booking Service - handles booking creation, cancellation, check-in and boarding pass generation.
 * Uses Feign client for inter-service communication with Flight Service.
 * Publishes events via RabbitMQ for downstream notification processing.
 */
@Service
@Transactional
public class BookingService {

    private static final Logger logger = LoggerFactory.getLogger(BookingService.class);

    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private FlightServiceClient flightServiceClient;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    /**
     * Creates a new booking for a passenger.
     * Fetches flight details from Flight Service, calculates fare, and persists the booking.
     */
    public BookingDto.BookingResponse createBooking(BookingDto.CreateBookingRequest request) {
        logger.info("Creating booking for user: {} on flight: {}", request.getUserId(), request.getFlightId());

        // Fetch flight details from Flight Service (inter-service call via Feign)
        FlightResponseDto flight = flightServiceClient.getFlightById(request.getFlightId());

        // Validate flight availability
        if ("CANCELLED".equals(flight.getStatus())) {
            throw new IllegalStateException("Cannot book a cancelled flight: " + request.getFlightId());
        }
        if (flight.getAvailableSeats() <= 0) {
            throw new IllegalStateException("No seats available for flight: " + flight.getFlightNumber());
        }

        // Create booking
        Booking booking = new Booking();
        booking.setUserId(request.getUserId());
        booking.setFlightId(request.getFlightId());
        booking.setPassengerName(request.getPassengerName());
        booking.setPassengerEmail(request.getPassengerEmail());
        booking.setPassengerPhone(request.getPassengerPhone());
        booking.setIdProofNumber(request.getIdProofNumber());
        booking.setTotalFare(flight.getCalculatedFare());
        booking.setStatus(Booking.BookingStatus.PENDING);
        booking.setBookingReference(generateBookingReference());
        booking.setSeatNumber(assignSeatNumber(flight));

        Booking savedBooking = bookingRepository.save(booking);
        logger.info("Booking created with reference: {}", savedBooking.getBookingReference());

        return mapToBookingResponse(savedBooking);
    }

    /**
     * Confirms a booking after successful payment.
     * Decrements available seats in Flight Service via Feign.
     * Publishes BookingEvent to RabbitMQ.
     */
    public BookingDto.BookingResponse confirmBooking(Long bookingId) {
        logger.info("Confirming booking ID: {}", bookingId);
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException(bookingId));

        if (booking.getStatus() != Booking.BookingStatus.PENDING) {
            throw new IllegalStateException("Only PENDING bookings can be confirmed. Current status: "
                    + booking.getStatus());
        }

        booking.setStatus(Booking.BookingStatus.CONFIRMED);
        Booking confirmed = bookingRepository.save(booking);

        // Decrement seat count in Flight Service
        try {
            flightServiceClient.decrementSeats(booking.getFlightId());
        } catch (Exception e) {
            logger.error("Failed to decrement seats for flight {}: {}", booking.getFlightId(), e.getMessage());
        }

        // Publish event to RabbitMQ
        publishBookingEvent("BOOKING_CONFIRMED", confirmed, RabbitMQConfig.BOOKING_CONFIRMED_KEY);

        logger.info("Booking confirmed: {}", confirmed.getBookingReference());
        return mapToBookingResponse(confirmed);
    }

    /**
     * Cancels a booking and frees up seat in Flight Service.
     */
    public BookingDto.BookingResponse cancelBooking(Long bookingId) {
        logger.info("Cancelling booking ID: {}", bookingId);
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException(bookingId));

        if (booking.getStatus() == Booking.BookingStatus.CANCELLED) {
            throw new IllegalStateException("Booking is already cancelled");
        }
        if (booking.getStatus() == Booking.BookingStatus.CHECKED_IN) {
            throw new IllegalStateException("Cannot cancel a booking that has already checked in");
        }

        boolean wasConfirmed = booking.getStatus() == Booking.BookingStatus.CONFIRMED;
        booking.setStatus(Booking.BookingStatus.CANCELLED);
        Booking cancelled = bookingRepository.save(booking);

        // Increment available seats if booking was previously confirmed
        if (wasConfirmed) {
            try {
                flightServiceClient.incrementSeats(booking.getFlightId());
            } catch (Exception e) {
                logger.error("Failed to increment seats for flight {}: {}", booking.getFlightId(), e.getMessage());
            }
        }

        // Publish cancellation event
        publishBookingEvent("BOOKING_CANCELLED", cancelled, RabbitMQConfig.BOOKING_CANCELLED_KEY);

        logger.info("Booking cancelled: {}", cancelled.getBookingReference());
        return mapToBookingResponse(cancelled);
    }

    /**
     * Performs check-in for a confirmed booking.
     * Generates boarding pass number.
     */
    public BookingDto.CheckInResponse performCheckIn(BookingDto.CheckInRequest request) {
        logger.info("Check-in request for booking: {}", request.getBookingReference());

        Booking booking = bookingRepository.findByBookingReference(request.getBookingReference())
                .orElseThrow(() -> new BookingNotFoundException(
                        "Booking not found with reference: " + request.getBookingReference()));

        if (booking.getStatus() != Booking.BookingStatus.CONFIRMED) {
            throw new IllegalStateException(
                    "Check-in is only allowed for CONFIRMED bookings. Current status: " + booking.getStatus());
        }
        if (booking.isCheckInStatus()) {
            throw new IllegalStateException("Passenger has already checked in for this booking");
        }

        // Perform check-in
        booking.setCheckInStatus(true);
        booking.setCheckInTime(LocalDateTime.now());
        booking.setBoardingPassNumber(generateBoardingPassNumber());
        booking.setStatus(Booking.BookingStatus.CHECKED_IN);

        Booking checkedIn = bookingRepository.save(booking);

        // Publish check-in event
        publishBookingEvent("CHECKED_IN", checkedIn, RabbitMQConfig.CHECKIN_KEY);

        logger.info("Check-in successful for booking: {}. Boarding pass: {}",
                checkedIn.getBookingReference(), checkedIn.getBoardingPassNumber());

        return new BookingDto.CheckInResponse(
                checkedIn.getBookingId(),
                checkedIn.getBookingReference(),
                checkedIn.getPassengerName(),
                checkedIn.getBoardingPassNumber(),
                checkedIn.getSeatNumber(),
                checkedIn.getCheckInTime(),
                "Check-in successful! Your boarding pass number is: " + checkedIn.getBoardingPassNumber()
        );
    }

    /**
     * Retrieves a booking by ID.
     */
    @Transactional(readOnly = true)
    public BookingDto.BookingResponse getBookingById(Long bookingId) {
        logger.debug("Fetching booking ID: {}", bookingId);
        Booking booking = bookingRepository.findById(bookingId)
                .orElseThrow(() -> new BookingNotFoundException(bookingId));
        return mapToBookingResponse(booking);
    }

    /**
     * Retrieves all bookings for a user.
     */
    @Transactional(readOnly = true)
    public List<BookingDto.BookingResponse> getBookingsByUserId(Long userId) {
        logger.debug("Fetching bookings for user ID: {}", userId);
        return bookingRepository.findByUserId(userId).stream()
                .map(this::mapToBookingResponse)
                .collect(Collectors.toList());
    }

    /**
     * Retrieves booking by reference number.
     */
    @Transactional(readOnly = true)
    public BookingDto.BookingResponse getBookingByReference(String reference) {
        Booking booking = bookingRepository.findByBookingReference(reference)
                .orElseThrow(() -> new BookingNotFoundException(
                        "Booking not found with reference: " + reference));
        return mapToBookingResponse(booking);
    }

    /**
     * Generates a unique 8-character alphanumeric booking reference.
     */
    private String generateBookingReference() {
        String ref;
        do {
            ref = UUID.randomUUID().toString().replaceAll("-", "")
                    .substring(0, 8).toUpperCase();
        } while (bookingRepository.existsByBookingReference(ref));
        return ref;
    }

    /**
     * Assigns a seat number based on available seats.
     */
    private String assignSeatNumber(FlightResponseDto flight) {
        int seatNum = new Random().nextInt(flight.getTotalSeats()) + 1;
        char row = (char) ('A' + (seatNum % 6));
        return seatNum + String.valueOf(row);
    }

    /**
     * Generates a boarding pass number.
     */
    private String generateBoardingPassNumber() {
        return "BP" + System.currentTimeMillis() % 100000L;
    }

    /**
     * Publishes a booking event to RabbitMQ.
     */
    private void publishBookingEvent(String eventType, Booking booking, String routingKey) {
        try {
            BookingEvent event = new BookingEvent(
                    eventType, booking.getBookingId(), booking.getBookingReference(),
                    booking.getUserId(), booking.getFlightId(), booking.getPassengerName(),
                    booking.getPassengerEmail(), booking.getPassengerPhone(),
                    booking.getTotalFare(), booking.getStatus().name(),
                    booking.getSeatNumber(), booking.getBoardingPassNumber(),
                    LocalDateTime.now()
            );
            rabbitTemplate.convertAndSend(RabbitMQConfig.BOOKING_EXCHANGE, routingKey, event);
            logger.info("Published {} event for booking: {}", eventType, booking.getBookingReference());
        } catch (Exception e) {
            logger.error("Failed to publish {} event: {}", eventType, e.getMessage());
        }
    }

    /**
     * Maps Booking entity to BookingResponse DTO.
     */
    private BookingDto.BookingResponse mapToBookingResponse(Booking booking) {
        return new BookingDto.BookingResponse(
                booking.getBookingId(), booking.getUserId(), booking.getFlightId(),
                booking.getPassengerName(), booking.getPassengerEmail(), booking.getPassengerPhone(),
                booking.getTotalFare(), booking.getStatus().name(), booking.getBookingReference(),
                booking.getSeatNumber(), booking.getBookingTime(), booking.isCheckInStatus(),
                booking.getCheckInTime(), booking.getBoardingPassNumber()
        );
    }
}
