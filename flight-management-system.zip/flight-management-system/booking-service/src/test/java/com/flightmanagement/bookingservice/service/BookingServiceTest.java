package com.flightmanagement.bookingservice.service;

import com.flightmanagement.bookingservice.config.FlightServiceClient;
import com.flightmanagement.bookingservice.dto.BookingDto;
import com.flightmanagement.bookingservice.dto.FlightResponseDto;
import com.flightmanagement.bookingservice.entity.Booking;
import com.flightmanagement.bookingservice.exception.BookingNotFoundException;
import com.flightmanagement.bookingservice.messaging.RabbitMQConfig;
import com.flightmanagement.bookingservice.repository.BookingRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit tests for BookingService using Mockito.
 */
@ExtendWith(MockitoExtension.class)
class BookingServiceTest {

    @Mock
    private BookingRepository bookingRepository;

    @Mock
    private FlightServiceClient flightServiceClient;

    @Mock
    private RabbitTemplate rabbitTemplate;

    @InjectMocks
    private BookingService bookingService;

    private Booking mockBooking;
    private FlightResponseDto mockFlight;
    private BookingDto.CreateBookingRequest createRequest;

    @BeforeEach
    void setUp() {
        mockFlight = new FlightResponseDto();
        mockFlight.setFlightId(1L);
        mockFlight.setFlightNumber("AI302");
        mockFlight.setStatus("SCHEDULED");
        mockFlight.setAvailableSeats(50);
        mockFlight.setTotalSeats(180);
        mockFlight.setBaseFare(BigDecimal.valueOf(3500));
        mockFlight.setCalculatedFare(BigDecimal.valueOf(3500));
        mockFlight.setTravelDate(LocalDate.of(2025, 12, 25));

        mockBooking = new Booking();
        mockBooking.setBookingId(1L);
        mockBooking.setUserId(1L);
        mockBooking.setFlightId(1L);
        mockBooking.setPassengerName("Joe Doe");
        mockBooking.setPassengerEmail("joe@example.com");
        mockBooking.setPassengerPhone("9876543210");
        mockBooking.setIdProofNumber("ABCDE1234F");
        mockBooking.setTotalFare(BigDecimal.valueOf(3500));
        mockBooking.setStatus(Booking.BookingStatus.PENDING);
        mockBooking.setBookingReference("REF12345");
        mockBooking.setSeatNumber("12A");
        mockBooking.setBookingTime(LocalDateTime.now());

        createRequest = new BookingDto.CreateBookingRequest(
                1L, 1L, "Joe Doe", "joe@example.com", "9876543210", "ABCDE1234F");
    }

    @Test
    @DisplayName("Should create booking successfully for a valid flight")
    void createBooking_Success() {
        when(flightServiceClient.getFlightById(1L)).thenReturn(mockFlight);
        when(bookingRepository.existsByBookingReference(anyString())).thenReturn(false);
        when(bookingRepository.save(any(Booking.class))).thenReturn(mockBooking);

        BookingDto.BookingResponse response = bookingService.createBooking(createRequest);

        assertNotNull(response);
        assertEquals("Joe Doe", response.getPassengerName());
        assertEquals("REF12345", response.getBookingReference());
        verify(bookingRepository).save(any(Booking.class));
    }

    @Test
    @DisplayName("Should throw exception when flight is cancelled")
    void createBooking_CancelledFlight_ThrowsException() {
        mockFlight.setStatus("CANCELLED");
        when(flightServiceClient.getFlightById(1L)).thenReturn(mockFlight);

        assertThrows(IllegalStateException.class, () -> bookingService.createBooking(createRequest));
    }

    @Test
    @DisplayName("Should throw exception when no seats available")
    void createBooking_NoSeats_ThrowsException() {
        mockFlight.setAvailableSeats(0);
        when(flightServiceClient.getFlightById(1L)).thenReturn(mockFlight);

        assertThrows(IllegalStateException.class, () -> bookingService.createBooking(createRequest));
    }

    @Test
    @DisplayName("Should confirm pending booking successfully")
    void confirmBooking_Success() {
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(mockBooking));
        mockBooking.setStatus(Booking.BookingStatus.PENDING);
        Booking confirmedBooking = new Booking();
        confirmedBooking.setBookingId(1L);
        confirmedBooking.setStatus(Booking.BookingStatus.CONFIRMED);
        confirmedBooking.setBookingReference("REF12345");
        confirmedBooking.setPassengerName("Joe Doe");
        confirmedBooking.setTotalFare(BigDecimal.valueOf(3500));
        when(bookingRepository.save(any(Booking.class))).thenReturn(confirmedBooking);

        BookingDto.BookingResponse response = bookingService.confirmBooking(1L);

        assertNotNull(response);
        assertEquals("CONFIRMED", response.getStatus());
        verify(flightServiceClient).decrementSeats(1L);
    }

    @Test
    @DisplayName("Should throw exception when confirming already confirmed booking")
    void confirmBooking_AlreadyConfirmed_ThrowsException() {
        mockBooking.setStatus(Booking.BookingStatus.CONFIRMED);
        when(bookingRepository.findById(1L)).thenReturn(Optional.of(mockBooking));

        assertThrows(IllegalStateException.class, () -> bookingService.confirmBooking(1L));
    }

    @Test
    @DisplayName("Should cancel confirmed booking and increment seats")
    void cancelBooking_Confirmed_IncrementsSeats() {
        mockBooking.setStatus(Booking.BookingStatus.CONFIRMED);
        Booking cancelled = new Booking();
        cancelled.setBookingId(1L);
        cancelled.setFlightId(1L);
        cancelled.setStatus(Booking.BookingStatus.CANCELLED);
        cancelled.setBookingReference("REF12345");
        cancelled.setPassengerName("Joe Doe");
        cancelled.setTotalFare(BigDecimal.valueOf(3500));

        when(bookingRepository.findById(1L)).thenReturn(Optional.of(mockBooking));
        when(bookingRepository.save(any(Booking.class))).thenReturn(cancelled);

        BookingDto.BookingResponse response = bookingService.cancelBooking(1L);

        assertNotNull(response);
        assertEquals("CANCELLED", response.getStatus());
        verify(flightServiceClient).incrementSeats(1L);
    }

    @Test
    @DisplayName("Should throw BookingNotFoundException for invalid booking ID")
    void getBookingById_NotFound_ThrowsException() {
        when(bookingRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(BookingNotFoundException.class, () -> bookingService.getBookingById(99L));
    }

    @Test
    @DisplayName("Should return all bookings for a user")
    void getBookingsByUserId_ReturnsAll() {
        when(bookingRepository.findByUserId(1L)).thenReturn(List.of(mockBooking));

        List<BookingDto.BookingResponse> results = bookingService.getBookingsByUserId(1L);

        assertFalse(results.isEmpty());
        assertEquals(1, results.size());
    }

    @Test
    @DisplayName("Should perform check-in for a confirmed booking")
    void performCheckIn_Success() {
        mockBooking.setStatus(Booking.BookingStatus.CONFIRMED);
        mockBooking.setCheckInStatus(false);

        Booking checkedIn = new Booking();
        checkedIn.setBookingId(1L);
        checkedIn.setStatus(Booking.BookingStatus.CHECKED_IN);
        checkedIn.setCheckInStatus(true);
        checkedIn.setCheckInTime(LocalDateTime.now());
        checkedIn.setBoardingPassNumber("BP12345");
        checkedIn.setBookingReference("REF12345");
        checkedIn.setSeatNumber("12A");
        checkedIn.setPassengerName("Joe Doe");

        when(bookingRepository.findByBookingReference("REF12345")).thenReturn(Optional.of(mockBooking));
        when(bookingRepository.save(any(Booking.class))).thenReturn(checkedIn);

        BookingDto.CheckInRequest checkInRequest = new BookingDto.CheckInRequest(1L, "REF12345");
        BookingDto.CheckInResponse response = bookingService.performCheckIn(checkInRequest);

        assertNotNull(response);
        assertEquals("REF12345", response.getBookingReference());
        assertNotNull(response.getBoardingPassNumber());
    }
}
