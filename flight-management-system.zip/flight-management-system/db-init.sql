-- ============================================================
-- Flight Management System - MySQL Database Initialization
-- Run this script once before starting the microservices
-- ============================================================

-- Create all databases
CREATE DATABASE IF NOT EXISTS flight_user_db;
CREATE DATABASE IF NOT EXISTS flight_flight_db;
CREATE DATABASE IF NOT EXISTS flight_booking_db;
CREATE DATABASE IF NOT EXISTS flight_payment_db;

-- ===========================
-- USER SERVICE DATABASE
-- ===========================
USE flight_user_db;

CREATE TABLE IF NOT EXISTS users (
    user_id     BIGINT AUTO_INCREMENT PRIMARY KEY,
    first_name  VARCHAR(50)  NOT NULL,
    last_name   VARCHAR(50)  NOT NULL,
    email       VARCHAR(100) NOT NULL UNIQUE,
    password    VARCHAR(255) NOT NULL,
    phone_number VARCHAR(15),
    role        ENUM('PASSENGER','ADMIN') NOT NULL DEFAULT 'PASSENGER',
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    created_at  DATETIME,
    updated_at  DATETIME
);

-- Seed admin user (password: admin123 - BCrypt encoded)
INSERT IGNORE INTO users (first_name, last_name, email, password, phone_number, role, is_active, created_at, updated_at)
VALUES ('System', 'Admin', 'admin@flightms.com',
        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy',
        '9000000000', 'ADMIN', TRUE, NOW(), NOW());

-- ===========================
-- FLIGHT SERVICE DATABASE
-- ===========================
USE flight_flight_db;

CREATE TABLE IF NOT EXISTS flights (
    flight_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    flight_number    VARCHAR(10)  NOT NULL UNIQUE,
    airline_name     VARCHAR(100) NOT NULL,
    source           VARCHAR(100) NOT NULL,
    destination      VARCHAR(100) NOT NULL,
    departure_time   DATETIME NOT NULL,
    arrival_time     DATETIME NOT NULL,
    travel_date      DATE NOT NULL,
    total_seats      INT NOT NULL,
    available_seats  INT NOT NULL,
    base_fare        DECIMAL(10,2) NOT NULL,
    status           ENUM('SCHEDULED','DELAYED','CANCELLED','COMPLETED') NOT NULL DEFAULT 'SCHEDULED',
    duration_minutes INT,
    created_at       DATETIME,
    updated_at       DATETIME
);

-- Seed sample flights
INSERT IGNORE INTO flights (flight_number, airline_name, source, destination, departure_time, arrival_time, travel_date, total_seats, available_seats, base_fare, status, duration_minutes, created_at, updated_at)
VALUES
('AI302',  'Air India',      'Mumbai',    'Delhi',     '2025-12-25 06:00:00', '2025-12-25 08:10:00', '2025-12-25', 180, 120, 3500.00, 'SCHEDULED', 130, NOW(), NOW()),
('6E201',  'IndiGo',         'Mumbai',    'Delhi',     '2025-12-25 09:00:00', '2025-12-25 11:05:00', '2025-12-25', 180,  90, 2800.00, 'SCHEDULED', 125, NOW(), NOW()),
('SG401',  'SpiceJet',       'Delhi',     'Bangalore', '2025-12-25 07:00:00', '2025-12-25 09:30:00', '2025-12-25', 150,  60, 3200.00, 'SCHEDULED', 150, NOW(), NOW()),
('AI501',  'Air India',      'Bangalore', 'Chennai',   '2025-12-25 10:00:00', '2025-12-25 11:10:00', '2025-12-25', 120, 100, 1800.00, 'SCHEDULED',  70, NOW(), NOW()),
('UK801',  'Vistara',        'Mumbai',    'Kolkata',   '2025-12-25 08:00:00', '2025-12-25 10:30:00', '2025-12-25', 160,  40, 4500.00, 'SCHEDULED', 150, NOW(), NOW()),
('6E305',  'IndiGo',         'Hyderabad', 'Mumbai',    '2025-12-25 12:00:00', '2025-12-25 14:00:00', '2025-12-25', 180, 150, 2600.00, 'SCHEDULED', 120, NOW(), NOW());

-- ===========================
-- BOOKING SERVICE DATABASE
-- ===========================
USE flight_booking_db;

CREATE TABLE IF NOT EXISTS bookings (
    booking_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id           BIGINT NOT NULL,
    flight_id         BIGINT NOT NULL,
    passenger_name    VARCHAR(100) NOT NULL,
    passenger_email   VARCHAR(100) NOT NULL,
    passenger_phone   VARCHAR(15)  NOT NULL,
    id_proof_number   VARCHAR(30)  NOT NULL,
    total_fare        DECIMAL(10,2) NOT NULL,
    status            ENUM('PENDING','CONFIRMED','CANCELLED','CHECKED_IN') NOT NULL DEFAULT 'PENDING',
    booking_reference VARCHAR(12) UNIQUE,
    seat_number       VARCHAR(10),
    booking_time      DATETIME,
    check_in_status   BOOLEAN NOT NULL DEFAULT FALSE,
    check_in_time     DATETIME,
    boarding_pass_number VARCHAR(20),
    created_at        DATETIME,
    updated_at        DATETIME
);

-- ===========================
-- PAYMENT SERVICE DATABASE
-- ===========================
USE flight_payment_db;

CREATE TABLE IF NOT EXISTS payments (
    payment_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_id        BIGINT NOT NULL,
    user_id           BIGINT NOT NULL,
    amount            DECIMAL(10,2) NOT NULL,
    payment_method    ENUM('CREDIT_CARD','DEBIT_CARD','NET_BANKING','UPI','WALLET') NOT NULL,
    status            ENUM('INITIATED','PENDING','SUCCESS','FAILED','REFUNDED') NOT NULL DEFAULT 'INITIATED',
    transaction_id    VARCHAR(50) UNIQUE,
    gateway_reference VARCHAR(100),
    failure_reason    VARCHAR(255),
    payment_time      DATETIME,
    refund_amount     DECIMAL(10,2),
    refund_time       DATETIME,
    refund_reference  VARCHAR(50),
    created_at        DATETIME,
    updated_at        DATETIME
);
