package com.flightmanagement.flightservice.controller;

import com.flightmanagement.flightservice.dto.FlightDto;
import com.flightmanagement.flightservice.service.FlightService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * REST Controller for Flight Management.
 * Exposes flight search, creation, and admin management endpoints.
 */
@RestController
@Tag(name = "Flight Management", description = "APIs for flight search and administration")
public class FlightController {

    private static final Logger logger = LoggerFactory.getLogger(FlightController.class);

    @Autowired
    private FlightService flightService;

    /**
     * Searches available flights. Requires authentication.
     * GET /api/flights?source=Mumbai&destination=Delhi&travelDate=2025-12-25
     */
    @GetMapping("/api/flights")
    @Operation(summary = "Search available flights", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<List<FlightDto.FlightResponse>> searchFlights(
            @RequestParam String source,
            @RequestParam String destination,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate travelDate) {
        logger.info("Searching flights: {} -> {} on {}", source, destination, travelDate);
        List<FlightDto.FlightResponse> flights = flightService.searchFlights(source, destination, travelDate);
        return ResponseEntity.ok(flights);
    }

    /**
     * Gets all flights. Requires authentication.
     * GET /api/flights/all
     */
    @GetMapping("/api/flights/all")
    @Operation(summary = "Get all flights", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<List<FlightDto.FlightResponse>> getAllFlights() {
        return ResponseEntity.ok(flightService.getAllFlights());
    }

    /**
     * Gets flight by ID.
     * GET /api/flights/{flightId}
     */
    @GetMapping("/api/flights/{flightId}")
    @Operation(summary = "Get flight by ID", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<FlightDto.FlightResponse> getFlightById(@PathVariable Long flightId) {
        return ResponseEntity.ok(flightService.getFlightById(flightId));
    }

    /**
     * Creates a new flight. Admin only.
     * POST /api/admin/flights
     */
    @PostMapping("/api/admin/flights")
    @Operation(summary = "Create a new flight (Admin only)", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<FlightDto.FlightResponse> createFlight(
            @Valid @RequestBody FlightDto.CreateFlightRequest request) {
        logger.info("Admin creating flight: {}", request.getFlightNumber());
        FlightDto.FlightResponse response = flightService.createFlight(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Updates a flight. Admin only.
     * PUT /api/admin/flights/{flightId}
     */
    @PutMapping("/api/admin/flights/{flightId}")
    @Operation(summary = "Update flight details (Admin only)", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<FlightDto.FlightResponse> updateFlight(
            @PathVariable Long flightId,
            @RequestBody FlightDto.UpdateFlightRequest request) {
        logger.info("Admin updating flight ID: {}", flightId);
        return ResponseEntity.ok(flightService.updateFlight(flightId, request));
    }

    /**
     * Cancels a flight. Admin only.
     * DELETE /api/admin/flights/{flightId}
     */
    @DeleteMapping("/api/admin/flights/{flightId}")
    @Operation(summary = "Cancel a flight (Admin only)", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> cancelFlight(@PathVariable Long flightId) {
        logger.info("Admin cancelling flight ID: {}", flightId);
        flightService.cancelFlight(flightId);
        return ResponseEntity.ok("Flight cancelled successfully");
    }

    /**
     * Internal endpoint: decrement available seats (called by Booking Service).
     * PUT /api/flights/{flightId}/decrement-seats
     */
    @PutMapping("/api/flights/{flightId}/decrement-seats")
    @Operation(summary = "Decrement available seats (internal use)", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<String> decrementSeats(@PathVariable Long flightId) {
        flightService.decrementAvailableSeats(flightId);
        return ResponseEntity.ok("Seat decremented");
    }

    /**
     * Internal endpoint: increment available seats on booking cancellation.
     * PUT /api/flights/{flightId}/increment-seats
     */
    @PutMapping("/api/flights/{flightId}/increment-seats")
    @Operation(summary = "Increment available seats (internal use)", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<String> incrementSeats(@PathVariable Long flightId) {
        flightService.incrementAvailableSeats(flightId);
        return ResponseEntity.ok("Seat incremented");
    }
}
