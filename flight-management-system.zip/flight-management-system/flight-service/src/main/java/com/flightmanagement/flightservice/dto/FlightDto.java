package com.flightmanagement.flightservice.dto;

import com.flightmanagement.flightservice.entity.Flight;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Data Transfer Objects for Flight Service API communication.
 */
public class FlightDto {

    /**
     * DTO for creating a new flight (Admin only).
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CreateFlightRequest {

        @NotBlank(message = "Flight number is required")
        @Pattern(regexp = "^[A-Z]{2}[0-9]{3,4}$", message = "Flight number format: AI302")
        private String flightNumber;

        @NotBlank(message = "Airline name is required")
        private String airlineName;

        @NotBlank(message = "Source is required")
        private String source;

        @NotBlank(message = "Destination is required")
        private String destination;

        @NotNull(message = "Departure time is required")
        private LocalDateTime departureTime;

        @NotNull(message = "Arrival time is required")
        private LocalDateTime arrivalTime;

        @NotNull(message = "Travel date is required")
        private LocalDate travelDate;

        @NotNull(message = "Total seats is required")
        @Min(value = 1)
        private Integer totalSeats;

        @NotNull(message = "Base fare is required")
        @DecimalMin(value = "0.0", inclusive = false)
        private BigDecimal baseFare;
    }

    /**
     * DTO for updating flight details (Admin only).
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class UpdateFlightRequest {
        private LocalDateTime departureTime;
        private LocalDateTime arrivalTime;
        private Integer availableSeats;
        private BigDecimal baseFare;
        private Flight.FlightStatus status;
    }

    /**
     * DTO for flight search query parameters.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FlightSearchRequest {

        @NotBlank(message = "Source is required")
        private String source;

        @NotBlank(message = "Destination is required")
        private String destination;

        @NotNull(message = "Travel date is required")
        private LocalDate travelDate;
    }

    /**
     * DTO for returning flight information.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FlightResponse {
        private Long flightId;
        private String flightNumber;
        private String airlineName;
        private String source;
        private String destination;
        private LocalDateTime departureTime;
        private LocalDateTime arrivalTime;
        private LocalDate travelDate;
        private Integer totalSeats;
        private Integer availableSeats;
        private BigDecimal baseFare;
        private BigDecimal calculatedFare;
        private String status;
        private Integer durationMinutes;
    }
}
