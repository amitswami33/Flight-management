package com.flightmanagement.flightservice.exception;

/**
 * Exception thrown when a flight with duplicate flight number is created.
 */
public class FlightAlreadyExistsException extends RuntimeException {

    public FlightAlreadyExistsException(String message) {
        super(message);
    }
}
