package com.flightmanagement.flightservice.exception;

/**
 * Exception thrown when a requested flight is not found.
 */
public class FlightNotFoundException extends RuntimeException {

    public FlightNotFoundException(String message) {
        super(message);
    }

    public FlightNotFoundException(Long flightId) {
        super("Flight not found with ID: " + flightId);
    }
}
