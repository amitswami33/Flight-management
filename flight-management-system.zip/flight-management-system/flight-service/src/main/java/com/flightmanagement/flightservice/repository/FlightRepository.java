package com.flightmanagement.flightservice.repository;

import com.flightmanagement.flightservice.entity.Flight;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * JPA Repository for Flight entity.
 * Contains custom query methods for flight search functionality.
 */
@Repository
public interface FlightRepository extends JpaRepository<Flight, Long> {

    /**
     * Searches for available flights by source, destination, and date.
     * Returns only SCHEDULED flights with available seats.
     */
    @Query("SELECT f FROM Flight f WHERE " +
            "LOWER(f.source) = LOWER(:source) AND " +
            "LOWER(f.destination) = LOWER(:destination) AND " +
            "f.travelDate = :travelDate AND " +
            "f.availableSeats > 0 AND " +
            "f.status = 'SCHEDULED'")
    List<Flight> searchAvailableFlights(
            @Param("source") String source,
            @Param("destination") String destination,
            @Param("travelDate") LocalDate travelDate
    );

    /**
     * Finds a flight by its flight number.
     */
    Optional<Flight> findByFlightNumber(String flightNumber);

    /**
     * Checks if a flight number already exists.
     */
    boolean existsByFlightNumber(String flightNumber);

    /**
     * Finds all flights departing from a given source.
     */
    List<Flight> findBySourceIgnoreCase(String source);

    /**
     * Finds all flights by status.
     */
    List<Flight> findByStatus(Flight.FlightStatus status);
}
