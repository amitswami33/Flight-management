package com.flightmanagement.flightservice.service;

import com.flightmanagement.flightservice.dto.FlightDto;
import com.flightmanagement.flightservice.entity.Flight;
import com.flightmanagement.flightservice.exception.FlightAlreadyExistsException;
import com.flightmanagement.flightservice.exception.FlightNotFoundException;
import com.flightmanagement.flightservice.repository.FlightRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Flight Service - handles flight creation, search, updates, and dynamic fare calculation.
 */
@Service
@Transactional
public class FlightService {

    private static final Logger logger = LoggerFactory.getLogger(FlightService.class);

    @Autowired
    private FlightRepository flightRepository;

    /**
     * Creates a new flight (Admin operation).
     */
    public FlightDto.FlightResponse createFlight(FlightDto.CreateFlightRequest request) {
        logger.info("Creating flight: {}", request.getFlightNumber());

        if (flightRepository.existsByFlightNumber(request.getFlightNumber())) {
            throw new FlightAlreadyExistsException(
                    "Flight already exists with number: " + request.getFlightNumber());
        }

        Flight flight = new Flight();
        flight.setFlightNumber(request.getFlightNumber());
        flight.setAirlineName(request.getAirlineName());
        flight.setSource(request.getSource());
        flight.setDestination(request.getDestination());
        flight.setDepartureTime(request.getDepartureTime());
        flight.setArrivalTime(request.getArrivalTime());
        flight.setTravelDate(request.getTravelDate());
        flight.setTotalSeats(request.getTotalSeats());
        flight.setAvailableSeats(request.getTotalSeats()); // Initially all seats available
        flight.setBaseFare(request.getBaseFare());
        flight.setDurationMinutes(
                (int) ChronoUnit.MINUTES.between(request.getDepartureTime(), request.getArrivalTime()));

        Flight saved = flightRepository.save(flight);
        logger.info("Flight created with ID: {}", saved.getFlightId());
        return mapToFlightResponse(saved);
    }

    /**
     * Searches available flights by source, destination, and date.
     * Applies dynamic pricing based on availability.
     */
    @Transactional(readOnly = true)
    public List<FlightDto.FlightResponse> searchFlights(
            String source, String destination, LocalDate travelDate) {
        logger.info("Searching flights: {} -> {} on {}", source, destination, travelDate);
        List<Flight> flights = flightRepository.searchAvailableFlights(source, destination, travelDate);
        logger.info("Found {} available flights", flights.size());
        return flights.stream()
                .map(this::mapToFlightResponse)
                .collect(Collectors.toList());
    }

    /**
     * Gets flight by ID.
     */
    @Transactional(readOnly = true)
    public FlightDto.FlightResponse getFlightById(Long flightId) {
        logger.debug("Fetching flight ID: {}", flightId);
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new FlightNotFoundException(flightId));
        return mapToFlightResponse(flight);
    }

    /**
     * Gets all flights (Admin operation).
     */
    @Transactional(readOnly = true)
    public List<FlightDto.FlightResponse> getAllFlights() {
        logger.debug("Fetching all flights");
        return flightRepository.findAll().stream()
                .map(this::mapToFlightResponse)
                .collect(Collectors.toList());
    }

    /**
     * Updates flight details (Admin operation).
     */
    public FlightDto.FlightResponse updateFlight(Long flightId, FlightDto.UpdateFlightRequest request) {
        logger.info("Updating flight ID: {}", flightId);
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new FlightNotFoundException(flightId));

        if (request.getDepartureTime() != null) flight.setDepartureTime(request.getDepartureTime());
        if (request.getArrivalTime() != null) flight.setArrivalTime(request.getArrivalTime());
        if (request.getAvailableSeats() != null) flight.setAvailableSeats(request.getAvailableSeats());
        if (request.getBaseFare() != null) flight.setBaseFare(request.getBaseFare());
        if (request.getStatus() != null) flight.setStatus(request.getStatus());

        return mapToFlightResponse(flightRepository.save(flight));
    }

    /**
     * Cancels a flight (Admin operation).
     */
    public void cancelFlight(Long flightId) {
        logger.info("Cancelling flight ID: {}", flightId);
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new FlightNotFoundException(flightId));
        flight.setStatus(Flight.FlightStatus.CANCELLED);
        flightRepository.save(flight);
    }

    /**
     * Reduces available seats by 1 when a booking is made.
     * Called internally via inter-service communication.
     */
    public void decrementAvailableSeats(Long flightId) {
        logger.info("Decrementing available seats for flight ID: {}", flightId);
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new FlightNotFoundException(flightId));

        if (flight.getAvailableSeats() <= 0) {
            throw new IllegalArgumentException("No available seats for flight: " + flightId);
        }
        flight.setAvailableSeats(flight.getAvailableSeats() - 1);
        flightRepository.save(flight);
    }

    /**
     * Increments available seats by 1 when a booking is cancelled.
     */
    public void incrementAvailableSeats(Long flightId) {
        logger.info("Incrementing available seats for flight ID: {}", flightId);
        Flight flight = flightRepository.findById(flightId)
                .orElseThrow(() -> new FlightNotFoundException(flightId));
        flight.setAvailableSeats(flight.getAvailableSeats() + 1);
        flightRepository.save(flight);
    }

    /**
     * Dynamic fare calculation based on seat availability (surge pricing logic).
     * - Occupancy > 80%: 30% surcharge
     * - Occupancy > 50%: 15% surcharge
     * - Otherwise: base fare applies
     */
    public BigDecimal calculateDynamicFare(Flight flight) {
        if (flight.getTotalSeats() == 0) return flight.getBaseFare();

        double occupancyRatio =
                (double) (flight.getTotalSeats() - flight.getAvailableSeats()) / flight.getTotalSeats();

        BigDecimal multiplier;
        if (occupancyRatio > 0.80) {
            multiplier = BigDecimal.valueOf(1.30);
        } else if (occupancyRatio > 0.50) {
            multiplier = BigDecimal.valueOf(1.15);
        } else {
            multiplier = BigDecimal.ONE;
        }

        return flight.getBaseFare().multiply(multiplier).setScale(2, RoundingMode.HALF_UP);
    }

    /**
     * Maps Flight entity to FlightResponse DTO.
     */
    private FlightDto.FlightResponse mapToFlightResponse(Flight flight) {
        FlightDto.FlightResponse response = new FlightDto.FlightResponse();
        response.setFlightId(flight.getFlightId());
        response.setFlightNumber(flight.getFlightNumber());
        response.setAirlineName(flight.getAirlineName());
        response.setSource(flight.getSource());
        response.setDestination(flight.getDestination());
        response.setDepartureTime(flight.getDepartureTime());
        response.setArrivalTime(flight.getArrivalTime());
        response.setTravelDate(flight.getTravelDate());
        response.setTotalSeats(flight.getTotalSeats());
        response.setAvailableSeats(flight.getAvailableSeats());
        response.setBaseFare(flight.getBaseFare());
        response.setCalculatedFare(calculateDynamicFare(flight));
        response.setStatus(flight.getStatus().name());
        response.setDurationMinutes(flight.getDurationMinutes());
        return response;
    }
}
