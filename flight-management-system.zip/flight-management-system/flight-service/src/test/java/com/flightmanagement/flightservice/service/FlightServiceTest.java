package com.flightmanagement.flightservice.service;

import com.flightmanagement.flightservice.dto.FlightDto;
import com.flightmanagement.flightservice.entity.Flight;
import com.flightmanagement.flightservice.exception.FlightAlreadyExistsException;
import com.flightmanagement.flightservice.exception.FlightNotFoundException;
import com.flightmanagement.flightservice.repository.FlightRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit tests for FlightService using Mockito.
 */
@ExtendWith(MockitoExtension.class)
class FlightServiceTest {

    @Mock
    private FlightRepository flightRepository;

    @InjectMocks
    private FlightService flightService;

    private Flight mockFlight;
    private FlightDto.CreateFlightRequest createRequest;

    @BeforeEach
    void setUp() {
        mockFlight = new Flight();
        mockFlight.setFlightId(1L);
        mockFlight.setFlightNumber("AI302");
        mockFlight.setAirlineName("Air India");
        mockFlight.setSource("Mumbai");
        mockFlight.setDestination("Delhi");
        mockFlight.setDepartureTime(LocalDateTime.of(2025, 12, 25, 10, 0));
        mockFlight.setArrivalTime(LocalDateTime.of(2025, 12, 25, 12, 0));
        mockFlight.setTravelDate(LocalDate.of(2025, 12, 25));
        mockFlight.setTotalSeats(180);
        mockFlight.setAvailableSeats(100);
        mockFlight.setBaseFare(BigDecimal.valueOf(3500.00));
        mockFlight.setStatus(Flight.FlightStatus.SCHEDULED);

        createRequest = new FlightDto.CreateFlightRequest();
        createRequest.setFlightNumber("AI302");
        createRequest.setAirlineName("Air India");
        createRequest.setSource("Mumbai");
        createRequest.setDestination("Delhi");
        createRequest.setDepartureTime(LocalDateTime.of(2025, 12, 25, 10, 0));
        createRequest.setArrivalTime(LocalDateTime.of(2025, 12, 25, 12, 0));
        createRequest.setTravelDate(LocalDate.of(2025, 12, 25));
        createRequest.setTotalSeats(180);
        createRequest.setBaseFare(BigDecimal.valueOf(3500.00));
    }

    @Test
    @DisplayName("Should create flight successfully when flight number is unique")
    void createFlight_Success() {
        when(flightRepository.existsByFlightNumber("AI302")).thenReturn(false);
        when(flightRepository.save(any(Flight.class))).thenReturn(mockFlight);

        FlightDto.FlightResponse response = flightService.createFlight(createRequest);

        assertNotNull(response);
        assertEquals("AI302", response.getFlightNumber());
        assertEquals("Mumbai", response.getSource());
        verify(flightRepository).save(any(Flight.class));
    }

    @Test
    @DisplayName("Should throw FlightAlreadyExistsException on duplicate flight number")
    void createFlight_DuplicateNumber_ThrowsException() {
        when(flightRepository.existsByFlightNumber("AI302")).thenReturn(true);

        assertThrows(FlightAlreadyExistsException.class,
                () -> flightService.createFlight(createRequest));
        verify(flightRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should return flights for valid search criteria")
    void searchFlights_ReturnsResults() {
        when(flightRepository.searchAvailableFlights(anyString(), anyString(), any(LocalDate.class)))
                .thenReturn(List.of(mockFlight));

        List<FlightDto.FlightResponse> results = flightService.searchFlights(
                "Mumbai", "Delhi", LocalDate.of(2025, 12, 25));

        assertFalse(results.isEmpty());
        assertEquals(1, results.size());
        assertEquals("AI302", results.get(0).getFlightNumber());
    }

    @Test
    @DisplayName("Should return empty list when no flights available")
    void searchFlights_NoResults_ReturnsEmptyList() {
        when(flightRepository.searchAvailableFlights(anyString(), anyString(), any(LocalDate.class)))
                .thenReturn(Collections.emptyList());

        List<FlightDto.FlightResponse> results = flightService.searchFlights(
                "Chennai", "Kolkata", LocalDate.of(2025, 12, 25));

        assertTrue(results.isEmpty());
    }

    @Test
    @DisplayName("Should throw FlightNotFoundException for invalid flight ID")
    void getFlightById_NotFound_ThrowsException() {
        when(flightRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(FlightNotFoundException.class, () -> flightService.getFlightById(99L));
    }

    @Test
    @DisplayName("Should decrement available seats successfully")
    void decrementAvailableSeats_Success() {
        when(flightRepository.findById(1L)).thenReturn(Optional.of(mockFlight));
        when(flightRepository.save(any(Flight.class))).thenReturn(mockFlight);

        flightService.decrementAvailableSeats(1L);

        assertEquals(99, mockFlight.getAvailableSeats());
        verify(flightRepository).save(mockFlight);
    }

    @Test
    @DisplayName("Should apply surge pricing when occupancy > 80%")
    void calculateDynamicFare_HighOccupancy_AppliesSurcharge() {
        // 80% seats occupied = 144 out of 180
        mockFlight.setAvailableSeats(36); // Only 36 available = 80% occupied

        BigDecimal fare = flightService.calculateDynamicFare(mockFlight);

        // 30% surcharge on 3500 = 4550
        assertEquals(BigDecimal.valueOf(4550.00).setScale(2), fare);
    }

    @Test
    @DisplayName("Should apply 15% surcharge when occupancy is between 50% and 80%")
    void calculateDynamicFare_MediumOccupancy_Applies15PercentSurcharge() {
        // 60% seats occupied = 108 out of 180
        mockFlight.setAvailableSeats(72);

        BigDecimal fare = flightService.calculateDynamicFare(mockFlight);

        // 15% surcharge on 3500 = 4025
        assertEquals(BigDecimal.valueOf(4025.00).setScale(2), fare);
    }

    @Test
    @DisplayName("Should return base fare when occupancy is below 50%")
    void calculateDynamicFare_LowOccupancy_ReturnsBaseFare() {
        // 40% occupied = 72 out of 180 used
        mockFlight.setAvailableSeats(108);

        BigDecimal fare = flightService.calculateDynamicFare(mockFlight);

        assertEquals(BigDecimal.valueOf(3500.00).setScale(2), fare);
    }
}
