package com.flightmanagement.paymentservice.config;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

/**
 * Feign client for inter-service communication with Booking Service.
 * Called after payment success/failure to update booking status.
 */
@FeignClient(name = "booking-service")
public interface BookingServiceClient {

    /**
     * Confirms booking after successful payment.
     */
    @PutMapping("/api/bookings/{bookingId}/confirm")
    void confirmBooking(@PathVariable("bookingId") Long bookingId);

    /**
     * Cancels booking after failed/refunded payment.
     */
    @PutMapping("/api/bookings/{bookingId}/cancel")
    void cancelBooking(@PathVariable("bookingId") Long bookingId);
}
