package com.flightmanagement.paymentservice.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Data Transfer Objects for Payment Service API.
 */
public class PaymentDto {

    /**
     * DTO for initiating a payment.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class InitiatePaymentRequest {

        @NotNull(message = "Booking ID is required")
        private Long bookingId;

        @NotNull(message = "User ID is required")
        private Long userId;

        @NotNull(message = "Amount is required")
        @DecimalMin(value = "0.0", inclusive = false, message = "Amount must be positive")
        private BigDecimal amount;

        @NotNull(message = "Payment method is required")
        private String paymentMethod;
    }

    /**
     * DTO for processing payment (simulates gateway callback).
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProcessPaymentRequest {

        @NotNull(message = "Payment ID is required")
        private Long paymentId;

        // Simulated card/UPI details (masked for security)
        @NotBlank(message = "Payment token is required")
        private String paymentToken;

        private String cardLastFour;
        private String upiId;
    }

    /**
     * DTO for payment response.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PaymentResponse {
        private Long paymentId;
        private Long bookingId;
        private Long userId;
        private BigDecimal amount;
        private String paymentMethod;
        private String status;
        private String transactionId;
        private String gatewayReference;
        private String failureReason;
        private LocalDateTime paymentTime;
        private BigDecimal refundAmount;
        private LocalDateTime refundTime;
        private String message;
    }

    /**
     * DTO for refund request.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RefundRequest {

        @NotNull(message = "Payment ID is required")
        private Long paymentId;

        @DecimalMin(value = "0.0", inclusive = false)
        private BigDecimal refundAmount;

        private String reason;
    }
}
