package com.flightmanagement.paymentservice.repository;

import com.flightmanagement.paymentservice.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

/**
 * JPA Repository for Payment entity.
 */
@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {

    /**
     * Finds payment by booking ID.
     */
    Optional<Payment> findByBookingId(Long bookingId);

    /**
     * Finds all payments by user ID.
     */
    List<Payment> findByUserId(Long userId);

    /**
     * Finds payment by transaction ID.
     */
    Optional<Payment> findByTransactionId(String transactionId);

    /**
     * Checks if a transaction ID already exists.
     */
    boolean existsByTransactionId(String transactionId);

    /**
     * Finds all payments with a given status.
     */
    List<Payment> findByStatus(Payment.PaymentStatus status);
}
