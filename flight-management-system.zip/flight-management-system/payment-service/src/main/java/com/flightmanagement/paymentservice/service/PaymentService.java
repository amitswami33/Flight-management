package com.flightmanagement.paymentservice.service;

import com.flightmanagement.paymentservice.config.BookingServiceClient;
import com.flightmanagement.paymentservice.dto.PaymentDto;
import com.flightmanagement.paymentservice.entity.Payment;
import com.flightmanagement.paymentservice.exception.PaymentNotFoundException;
import com.flightmanagement.paymentservice.repository.PaymentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Random;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Payment Service - handles payment initiation, processing, and refunds.
 * Simulates payment gateway interaction with a mock success/failure logic.
 * On success: calls Booking Service to confirm booking via Feign.
 * On failure: calls Booking Service to cancel booking via Feign.
 */
@Service
@Transactional
public class PaymentService {

    private static final Logger logger = LoggerFactory.getLogger(PaymentService.class);

    @Autowired
    private PaymentRepository paymentRepository;

    @Autowired
    private BookingServiceClient bookingServiceClient;

    /**
     * Initiates a payment transaction for a booking.
     * Creates a payment record in INITIATED state.
     */
    public PaymentDto.PaymentResponse initiatePayment(PaymentDto.InitiatePaymentRequest request) {
        logger.info("Initiating payment for booking ID: {}", request.getBookingId());

        // Validate no duplicate payment for same booking
        paymentRepository.findByBookingId(request.getBookingId()).ifPresent(p -> {
            if (p.getStatus() == Payment.PaymentStatus.SUCCESS) {
                throw new IllegalStateException("Payment already completed for booking: " + request.getBookingId());
            }
        });

        Payment payment = new Payment();
        payment.setBookingId(request.getBookingId());
        payment.setUserId(request.getUserId());
        payment.setAmount(request.getAmount());
        payment.setPaymentMethod(Payment.PaymentMethod.valueOf(request.getPaymentMethod().toUpperCase()));
        payment.setStatus(Payment.PaymentStatus.INITIATED);
        payment.setTransactionId(generateTransactionId());

        Payment saved = paymentRepository.save(payment);
        logger.info("Payment initiated with transaction ID: {}", saved.getTransactionId());

        return mapToPaymentResponse(saved, "Payment initiated. Please proceed with payment.");
    }

    /**
     * Processes a payment by simulating gateway interaction.
     * 90% success rate simulation. On success, confirms booking via Feign.
     * On failure, cancels booking via Feign.
     */
    public PaymentDto.PaymentResponse processPayment(PaymentDto.ProcessPaymentRequest request) {
        logger.info("Processing payment ID: {}", request.getPaymentId());

        Payment payment = paymentRepository.findById(request.getPaymentId())
                .orElseThrow(() -> new PaymentNotFoundException(request.getPaymentId()));

        if (payment.getStatus() != Payment.PaymentStatus.INITIATED
                && payment.getStatus() != Payment.PaymentStatus.PENDING) {
            throw new IllegalStateException("Payment cannot be processed. Current status: " + payment.getStatus());
        }

        payment.setStatus(Payment.PaymentStatus.PENDING);
        paymentRepository.save(payment);

        // Simulate payment gateway processing (90% success rate)
        boolean paymentSuccess = simulateGatewayCall(request.getPaymentToken());

        if (paymentSuccess) {
            payment.setStatus(Payment.PaymentStatus.SUCCESS);
            payment.setGatewayReference("GW-" + UUID.randomUUID().toString().substring(0, 10).toUpperCase());
            payment.setPaymentTime(LocalDateTime.now());
            Payment processed = paymentRepository.save(payment);

            // Confirm booking via Feign inter-service call
            try {
                bookingServiceClient.confirmBooking(payment.getBookingId());
                logger.info("Booking confirmed for payment: {}", payment.getTransactionId());
            } catch (Exception e) {
                logger.error("Failed to confirm booking {}: {}", payment.getBookingId(), e.getMessage());
            }

            logger.info("Payment SUCCESS for transaction: {}", payment.getTransactionId());
            return mapToPaymentResponse(processed,
                    "Payment successful! Transaction ID: " + processed.getTransactionId());
        } else {
            payment.setStatus(Payment.PaymentStatus.FAILED);
            payment.setFailureReason("Payment declined by bank. Please try again or use a different payment method.");
            Payment failed = paymentRepository.save(payment);

            // Cancel booking via Feign inter-service call
            try {
                bookingServiceClient.cancelBooking(payment.getBookingId());
                logger.info("Booking cancelled due to payment failure: {}", payment.getBookingId());
            } catch (Exception e) {
                logger.error("Failed to cancel booking {}: {}", payment.getBookingId(), e.getMessage());
            }

            logger.warn("Payment FAILED for transaction: {}", payment.getTransactionId());
            return mapToPaymentResponse(failed,
                    "Payment failed: " + failed.getFailureReason());
        }
    }

    /**
     * Processes a refund for a successful payment.
     */
    public PaymentDto.PaymentResponse processRefund(PaymentDto.RefundRequest request) {
        logger.info("Processing refund for payment ID: {}", request.getPaymentId());

        Payment payment = paymentRepository.findById(request.getPaymentId())
                .orElseThrow(() -> new PaymentNotFoundException(request.getPaymentId()));

        if (payment.getStatus() != Payment.PaymentStatus.SUCCESS) {
            throw new IllegalStateException("Refund is only possible for successful payments. Current: "
                    + payment.getStatus());
        }

        BigDecimal refundAmount = request.getRefundAmount() != null
                ? request.getRefundAmount()
                : payment.getAmount(); // Full refund if amount not specified

        payment.setStatus(Payment.PaymentStatus.REFUNDED);
        payment.setRefundAmount(refundAmount);
        payment.setRefundTime(LocalDateTime.now());
        payment.setRefundReference("REF-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase());

        Payment refunded = paymentRepository.save(payment);
        logger.info("Refund processed for transaction: {}", payment.getTransactionId());
        return mapToPaymentResponse(refunded, "Refund of ₹" + refundAmount + " processed successfully.");
    }

    /**
     * Gets payment details by payment ID.
     */
    @Transactional(readOnly = true)
    public PaymentDto.PaymentResponse getPaymentById(Long paymentId) {
        Payment payment = paymentRepository.findById(paymentId)
                .orElseThrow(() -> new PaymentNotFoundException(paymentId));
        return mapToPaymentResponse(payment, null);
    }

    /**
     * Gets payment by booking ID.
     */
    @Transactional(readOnly = true)
    public PaymentDto.PaymentResponse getPaymentByBookingId(Long bookingId) {
        Payment payment = paymentRepository.findByBookingId(bookingId)
                .orElseThrow(() -> new PaymentNotFoundException("Payment not found for booking: " + bookingId));
        return mapToPaymentResponse(payment, null);
    }

    /**
     * Gets all payments for a user.
     */
    @Transactional(readOnly = true)
    public List<PaymentDto.PaymentResponse> getPaymentsByUserId(Long userId) {
        return paymentRepository.findByUserId(userId).stream()
                .map(p -> mapToPaymentResponse(p, null))
                .collect(Collectors.toList());
    }

    /**
     * Generates a unique transaction ID.
     */
    private String generateTransactionId() {
        String txnId;
        do {
            txnId = "TXN" + System.currentTimeMillis() % 1000000000L;
        } while (paymentRepository.existsByTransactionId(txnId));
        return txnId;
    }

    /**
     * Simulates gateway call with 90% success probability.
     * In production, this would call an actual payment gateway API.
     */
    private boolean simulateGatewayCall(String paymentToken) {
        // token "FAIL_TEST" always fails for testing
        if ("FAIL_TEST".equalsIgnoreCase(paymentToken)) return false;
        return new Random().nextInt(10) < 9; // 90% success rate
    }

    /**
     * Maps Payment entity to PaymentResponse DTO.
     */
    private PaymentDto.PaymentResponse mapToPaymentResponse(Payment payment, String message) {
        return new PaymentDto.PaymentResponse(
                payment.getPaymentId(), payment.getBookingId(), payment.getUserId(),
                payment.getAmount(), payment.getPaymentMethod().name(), payment.getStatus().name(),
                payment.getTransactionId(), payment.getGatewayReference(), payment.getFailureReason(),
                payment.getPaymentTime(), payment.getRefundAmount(), payment.getRefundTime(),
                message
        );
    }
}
