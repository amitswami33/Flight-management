package com.flightmanagement.paymentservice.service;

import com.flightmanagement.paymentservice.config.BookingServiceClient;
import com.flightmanagement.paymentservice.dto.PaymentDto;
import com.flightmanagement.paymentservice.entity.Payment;
import com.flightmanagement.paymentservice.exception.PaymentNotFoundException;
import com.flightmanagement.paymentservice.repository.PaymentRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {

    @Mock
    private PaymentRepository paymentRepository;

    @Mock
    private BookingServiceClient bookingServiceClient;

    @InjectMocks
    private PaymentService paymentService;

    private Payment mockPayment;
    private PaymentDto.InitiatePaymentRequest initiateRequest;

    @BeforeEach
    void setUp() {
        mockPayment = new Payment();
        mockPayment.setPaymentId(1L);
        mockPayment.setBookingId(1L);
        mockPayment.setUserId(1L);
        mockPayment.setAmount(BigDecimal.valueOf(3500));
        mockPayment.setPaymentMethod(Payment.PaymentMethod.UPI);
        mockPayment.setStatus(Payment.PaymentStatus.INITIATED);
        mockPayment.setTransactionId("TXN123456789");

        initiateRequest = new PaymentDto.InitiatePaymentRequest(
                1L, 1L, BigDecimal.valueOf(3500), "UPI");
    }

    @Test
    @DisplayName("Should initiate payment successfully")
    void initiatePayment_Success() {
        when(paymentRepository.findByBookingId(1L)).thenReturn(Optional.empty());
        when(paymentRepository.existsByTransactionId(any())).thenReturn(false);
        when(paymentRepository.save(any(Payment.class))).thenReturn(mockPayment);

        PaymentDto.PaymentResponse response = paymentService.initiatePayment(initiateRequest);

        assertNotNull(response);
        assertEquals(1L, response.getBookingId());
        assertEquals("INITIATED", response.getStatus());
        verify(paymentRepository).save(any(Payment.class));
    }

    @Test
    @DisplayName("Should throw exception for already paid booking")
    void initiatePayment_AlreadyPaid_ThrowsException() {
        mockPayment.setStatus(Payment.PaymentStatus.SUCCESS);
        when(paymentRepository.findByBookingId(1L)).thenReturn(Optional.of(mockPayment));

        assertThrows(IllegalStateException.class, () -> paymentService.initiatePayment(initiateRequest));
    }

    @Test
    @DisplayName("Should process payment successfully with PASS token")
    void processPayment_WithPassToken_Success() {
        when(paymentRepository.findById(1L)).thenReturn(Optional.of(mockPayment));
        Payment successPayment = new Payment();
        successPayment.setPaymentId(1L);
        successPayment.setBookingId(1L);
        successPayment.setUserId(1L);
        successPayment.setAmount(BigDecimal.valueOf(3500));
        successPayment.setPaymentMethod(Payment.PaymentMethod.UPI);
        successPayment.setStatus(Payment.PaymentStatus.SUCCESS);
        successPayment.setTransactionId("TXN123456789");
        when(paymentRepository.save(any(Payment.class))).thenReturn(successPayment);

        PaymentDto.ProcessPaymentRequest processRequest =
                new PaymentDto.ProcessPaymentRequest(1L, "VALID_TOKEN", null, "joe@upi");
        PaymentDto.PaymentResponse response = paymentService.processPayment(processRequest);

        assertNotNull(response);
        // Result may be SUCCESS or FAILED due to random simulation
        assertNotNull(response.getStatus());
    }

    @Test
    @DisplayName("Should always fail payment with FAIL_TEST token")
    void processPayment_WithFailToken_Fails() {
        when(paymentRepository.findById(1L)).thenReturn(Optional.of(mockPayment));
        Payment failedPayment = new Payment();
        failedPayment.setPaymentId(1L);
        failedPayment.setBookingId(1L);
        failedPayment.setStatus(Payment.PaymentStatus.FAILED);
        failedPayment.setTransactionId("TXN123456789");
        failedPayment.setFailureReason("Payment declined by bank.");
        failedPayment.setPaymentMethod(Payment.PaymentMethod.UPI);
        failedPayment.setAmount(BigDecimal.valueOf(3500));
        failedPayment.setUserId(1L);
        when(paymentRepository.save(any(Payment.class))).thenReturn(failedPayment);

        PaymentDto.ProcessPaymentRequest failRequest =
                new PaymentDto.ProcessPaymentRequest(1L, "FAIL_TEST", null, null);
        PaymentDto.PaymentResponse response = paymentService.processPayment(failRequest);

        assertEquals("FAILED", response.getStatus());
        verify(bookingServiceClient).cancelBooking(1L);
    }

    @Test
    @DisplayName("Should process refund for successful payment")
    void processRefund_Success() {
        mockPayment.setStatus(Payment.PaymentStatus.SUCCESS);
        Payment refundedPayment = new Payment();
        refundedPayment.setPaymentId(1L);
        refundedPayment.setBookingId(1L);
        refundedPayment.setUserId(1L);
        refundedPayment.setAmount(BigDecimal.valueOf(3500));
        refundedPayment.setStatus(Payment.PaymentStatus.REFUNDED);
        refundedPayment.setRefundAmount(BigDecimal.valueOf(3500));
        refundedPayment.setPaymentMethod(Payment.PaymentMethod.UPI);
        refundedPayment.setTransactionId("TXN123456789");

        when(paymentRepository.findById(1L)).thenReturn(Optional.of(mockPayment));
        when(paymentRepository.save(any(Payment.class))).thenReturn(refundedPayment);

        PaymentDto.RefundRequest refundRequest = new PaymentDto.RefundRequest(1L, null, "Cancelled booking");
        PaymentDto.PaymentResponse response = paymentService.processRefund(refundRequest);

        assertNotNull(response);
        assertEquals("REFUNDED", response.getStatus());
    }

    @Test
    @DisplayName("Should throw exception on refund for non-success payment")
    void processRefund_NonSuccessPayment_ThrowsException() {
        mockPayment.setStatus(Payment.PaymentStatus.FAILED);
        when(paymentRepository.findById(1L)).thenReturn(Optional.of(mockPayment));

        PaymentDto.RefundRequest refundRequest = new PaymentDto.RefundRequest(1L, null, "test");
        assertThrows(IllegalStateException.class, () -> paymentService.processRefund(refundRequest));
    }

    @Test
    @DisplayName("Should throw PaymentNotFoundException for invalid ID")
    void getPaymentById_NotFound_ThrowsException() {
        when(paymentRepository.findById(99L)).thenReturn(Optional.empty());
        assertThrows(PaymentNotFoundException.class, () -> paymentService.getPaymentById(99L));
    }

    @Test
    @DisplayName("Should return all payments for a user")
    void getPaymentsByUserId_ReturnsList() {
        when(paymentRepository.findByUserId(1L)).thenReturn(List.of(mockPayment));
        List<PaymentDto.PaymentResponse> results = paymentService.getPaymentsByUserId(1L);
        assertEquals(1, results.size());
    }
}
