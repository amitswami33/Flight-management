package com.flightmanagement.userservice.controller;

import com.flightmanagement.userservice.dto.UserDto;
import com.flightmanagement.userservice.service.UserService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * REST Controller for User Management.
 * Exposes endpoints for registration, login, and profile management.
 */
@RestController
@RequestMapping("/api/users")
@Tag(name = "User Management", description = "APIs for user registration, login, and profile management")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    @Autowired
    private UserService userService;

    /**
     * Registers a new user (Passenger or Admin).
     * POST /api/users/register
     */
    @PostMapping("/register")
    @Operation(summary = "Register a new user")
    public ResponseEntity<UserDto.AuthResponse> registerUser(@Valid @RequestBody UserDto.RegisterRequest request) {
        logger.info("Received registration request for email: {}", request.getEmail());
        UserDto.AuthResponse response = userService.registerUser(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * Authenticates user and returns JWT token.
     * POST /api/users/login
     */
    @PostMapping("/login")
    @Operation(summary = "Login and receive JWT token")
    public ResponseEntity<UserDto.AuthResponse> loginUser(@Valid @RequestBody UserDto.LoginRequest request) {
        logger.info("Login request for email: {}", request.getEmail());
        UserDto.AuthResponse response = userService.loginUser(request);
        return ResponseEntity.ok(response);
    }

    /**
     * Gets user profile by ID. Requires authentication.
     * GET /api/users/{userId}
     */
    @GetMapping("/{userId}")
    @Operation(summary = "Get user profile by ID", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<UserDto.UserResponse> getUserById(@PathVariable Long userId) {
        logger.debug("Fetching user profile for ID: {}", userId);
        UserDto.UserResponse response = userService.getUserById(userId);
        return ResponseEntity.ok(response);
    }

    /**
     * Gets user profile by email. Requires authentication.
     * GET /api/users/email/{email}
     */
    @GetMapping("/email/{email}")
    @Operation(summary = "Get user profile by email", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<UserDto.UserResponse> getUserByEmail(@PathVariable String email) {
        logger.debug("Fetching user profile for email: {}", email);
        UserDto.UserResponse response = userService.getUserByEmail(email);
        return ResponseEntity.ok(response);
    }

    /**
     * Updates user profile. Requires authentication.
     * PUT /api/users/{userId}
     */
    @PutMapping("/{userId}")
    @Operation(summary = "Update user profile", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasAnyRole('PASSENGER', 'ADMIN')")
    public ResponseEntity<UserDto.UserResponse> updateUserProfile(
            @PathVariable Long userId,
            @Valid @RequestBody UserDto.UpdateProfileRequest request) {
        logger.info("Updating user profile for ID: {}", userId);
        UserDto.UserResponse response = userService.updateUserProfile(userId, request);
        return ResponseEntity.ok(response);
    }

    /**
     * Deactivates a user account. Admin only.
     * DELETE /api/users/{userId}
     */
    @DeleteMapping("/{userId}")
    @Operation(summary = "Deactivate user account (Admin only)", security = @SecurityRequirement(name = "bearerAuth"))
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<String> deactivateUser(@PathVariable Long userId) {
        logger.info("Admin deactivating user ID: {}", userId);
        userService.deactivateUser(userId);
        return ResponseEntity.ok("User deactivated successfully");
    }
}
