package com.flightmanagement.userservice.service;

import com.flightmanagement.userservice.dto.UserDto;

/**
 * Service interface for User operations.
 * Defines the contract for user registration, authentication, and profile management.
 */
public interface UserService {

    /**
     * Registers a new user in the system.
     *
     * @param request registration details
     * @return authentication response with JWT token
     */
    UserDto.AuthResponse registerUser(UserDto.RegisterRequest request);

    /**
     * Authenticates a user with email and password.
     *
     * @param request login credentials
     * @return authentication response with JWT token
     */
    UserDto.AuthResponse loginUser(UserDto.LoginRequest request);

    /**
     * Retrieves user profile by user ID.
     *
     * @param userId the user's ID
     * @return user profile response
     */
    UserDto.UserResponse getUserById(Long userId);

    /**
     * Retrieves user profile by email.
     *
     * @param email the user's email
     * @return user profile response
     */
    UserDto.UserResponse getUserByEmail(String email);

    /**
     * Updates a user's profile information.
     *
     * @param userId  the user's ID
     * @param request updated profile fields
     * @return updated user profile response
     */
    UserDto.UserResponse updateUserProfile(Long userId, UserDto.UpdateProfileRequest request);

    /**
     * Deactivates a user account.
     *
     * @param userId the user's ID
     */
    void deactivateUser(Long userId);
}
