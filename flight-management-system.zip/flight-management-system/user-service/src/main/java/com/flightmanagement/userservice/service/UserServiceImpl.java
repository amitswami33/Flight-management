package com.flightmanagement.userservice.service;

import com.flightmanagement.userservice.dto.UserDto;
import com.flightmanagement.userservice.entity.User;
import com.flightmanagement.userservice.exception.UserAlreadyExistsException;
import com.flightmanagement.userservice.exception.UserNotFoundException;
import com.flightmanagement.userservice.repository.UserRepository;
import com.flightmanagement.userservice.security.JwtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Implementation of UserService.
 * Handles business logic for user registration, login, and profile management.
 */
@Service
@Transactional
public class UserServiceImpl implements UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserDetailsService userDetailsService;

    /**
     * Registers a new user after checking for duplicate email.
     * Password is hashed using BCrypt before persisting.
     */
    @Override
    public UserDto.AuthResponse registerUser(UserDto.RegisterRequest request) {
        logger.info("Attempting to register user with email: {}", request.getEmail());

        // Check for duplicate email
        if (userRepository.existsByEmail(request.getEmail())) {
            logger.warn("Registration failed - email already exists: {}", request.getEmail());
            throw new UserAlreadyExistsException("User already exists with email: " + request.getEmail());
        }

        // Build and persist user
        User user = new User();
        user.setFirstName(request.getFirstName());
        user.setLastName(request.getLastName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setPhoneNumber(request.getPhoneNumber());
        user.setRole(request.getRole() != null ? request.getRole() : User.Role.PASSENGER);

        User savedUser = userRepository.save(user);
        logger.info("User registered successfully with ID: {}", savedUser.getUserId());

        // Generate JWT token
        UserDetails userDetails = userDetailsService.loadUserByUsername(savedUser.getEmail());
        String token = jwtService.generateToken(userDetails, savedUser.getRole().name());

        return new UserDto.AuthResponse(token, savedUser.getUserId(), savedUser.getEmail(),
                savedUser.getRole().name());
    }

    /**
     * Authenticates user credentials and returns a JWT token.
     */
    @Override
    public UserDto.AuthResponse loginUser(UserDto.LoginRequest request) {
        logger.info("Login attempt for email: {}", request.getEmail());

        // Spring Security handles credential validation
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getEmail(), request.getPassword())
        );

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + request.getEmail()));

        UserDetails userDetails = userDetailsService.loadUserByUsername(user.getEmail());
        String token = jwtService.generateToken(userDetails, user.getRole().name());

        logger.info("User logged in successfully: {}", user.getEmail());
        return new UserDto.AuthResponse(token, user.getUserId(), user.getEmail(), user.getRole().name());
    }

    /**
     * Retrieves user profile by ID.
     */
    @Override
    @Transactional(readOnly = true)
    public UserDto.UserResponse getUserById(Long userId) {
        logger.debug("Fetching user by ID: {}", userId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));
        return mapToUserResponse(user);
    }

    /**
     * Retrieves user profile by email.
     */
    @Override
    @Transactional(readOnly = true)
    public UserDto.UserResponse getUserByEmail(String email) {
        logger.debug("Fetching user by email: {}", email);
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new UserNotFoundException("User not found with email: " + email));
        return mapToUserResponse(user);
    }

    /**
     * Updates allowed profile fields (name, phone).
     */
    @Override
    public UserDto.UserResponse updateUserProfile(Long userId, UserDto.UpdateProfileRequest request) {
        logger.info("Updating profile for user ID: {}", userId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));

        if (request.getFirstName() != null && !request.getFirstName().isBlank()) {
            user.setFirstName(request.getFirstName());
        }
        if (request.getLastName() != null && !request.getLastName().isBlank()) {
            user.setLastName(request.getLastName());
        }
        if (request.getPhoneNumber() != null && !request.getPhoneNumber().isBlank()) {
            user.setPhoneNumber(request.getPhoneNumber());
        }

        User updatedUser = userRepository.save(user);
        logger.info("User profile updated for ID: {}", userId);
        return mapToUserResponse(updatedUser);
    }

    /**
     * Deactivates a user account by setting isActive to false.
     */
    @Override
    public void deactivateUser(Long userId) {
        logger.info("Deactivating user with ID: {}", userId);
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));
        user.setActive(false);
        userRepository.save(user);
        logger.info("User deactivated: {}", userId);
    }

    /**
     * Maps User entity to UserResponse DTO.
     */
    private UserDto.UserResponse mapToUserResponse(User user) {
        return new UserDto.UserResponse(
                user.getUserId(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getPhoneNumber(),
                user.getRole().name(),
                user.isActive(),
                user.getCreatedAt()
        );
    }
}
