package com.flightmanagement.userservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.flightmanagement.userservice.dto.UserDto;
import com.flightmanagement.userservice.exception.UserAlreadyExistsException;
import com.flightmanagement.userservice.exception.UserNotFoundException;
import com.flightmanagement.userservice.security.JwtAuthFilter;
import com.flightmanagement.userservice.security.JwtService;
import com.flightmanagement.userservice.service.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.FilterType;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;
import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Unit tests for UserController using MockMvc.
 * Tests HTTP request/response handling, input validation, and exception mapping.
 */
@WebMvcTest(value = UserController.class,
        excludeFilters = @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE,
                classes = JwtAuthFilter.class))
class UserControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserService userService;

    @MockBean
    private JwtService jwtService;

    private UserDto.RegisterRequest registerRequest;
    private UserDto.AuthResponse authResponse;
    private UserDto.UserResponse userResponse;

    @BeforeEach
    void setUp() {
        registerRequest = new UserDto.RegisterRequest();
        registerRequest.setFirstName("Joe");
        registerRequest.setLastName("Doe");
        registerRequest.setEmail("joe@example.com");
        registerRequest.setPassword("password123");
        registerRequest.setPhoneNumber("9876543210");

        authResponse = new UserDto.AuthResponse("mock-token", 1L, "joe@example.com", "PASSENGER");

        userResponse = new UserDto.UserResponse(1L, "Joe", "Doe", "joe@example.com",
                "9876543210", "PASSENGER", true, null);
    }

    @Test
    @DisplayName("POST /api/users/register - Should return 201 on successful registration")
    void registerUser_Success_Returns201() throws Exception {
        when(userService.registerUser(any(UserDto.RegisterRequest.class))).thenReturn(authResponse);

        mockMvc.perform(post("/api/users/register")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(registerRequest)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.token").value("mock-token"))
                .andExpect(jsonPath("$.email").value("joe@example.com"));
    }

    @Test
    @DisplayName("POST /api/users/register - Should return 409 if email already exists")
    void registerUser_DuplicateEmail_Returns409() throws Exception {
        when(userService.registerUser(any())).thenThrow(
                new UserAlreadyExistsException("User already exists with email: joe@example.com"));

        mockMvc.perform(post("/api/users/register")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(registerRequest)))
                .andExpect(status().isConflict())
                .andExpect(jsonPath("$.status").value(409));
    }

    @Test
    @DisplayName("POST /api/users/register - Should return 400 on invalid input")
    void registerUser_InvalidInput_Returns400() throws Exception {
        UserDto.RegisterRequest invalidRequest = new UserDto.RegisterRequest();
        invalidRequest.setEmail("not-a-valid-email");
        // Missing required fields

        mockMvc.perform(post("/api/users/register")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(invalidRequest)))
                .andExpect(status().isBadRequest());
    }

    @Test
    @DisplayName("POST /api/users/login - Should return 200 with token on successful login")
    void loginUser_Success_Returns200() throws Exception {
        UserDto.LoginRequest loginRequest = new UserDto.LoginRequest("joe@example.com", "password123");
        when(userService.loginUser(any(UserDto.LoginRequest.class))).thenReturn(authResponse);

        mockMvc.perform(post("/api/users/login")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").value("mock-token"));
    }

    @Test
    @DisplayName("GET /api/users/{userId} - Should return 200 with user profile")
    @WithMockUser(roles = "PASSENGER")
    void getUserById_Found_Returns200() throws Exception {
        when(userService.getUserById(1L)).thenReturn(userResponse);

        mockMvc.perform(get("/api/users/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.userId").value(1))
                .andExpect(jsonPath("$.email").value("joe@example.com"));
    }

    @Test
    @DisplayName("GET /api/users/{userId} - Should return 404 when user not found")
    @WithMockUser(roles = "PASSENGER")
    void getUserById_NotFound_Returns404() throws Exception {
        when(userService.getUserById(99L)).thenThrow(new UserNotFoundException(99L));

        mockMvc.perform(get("/api/users/99"))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404));
    }

    @Test
    @DisplayName("PUT /api/users/{userId} - Should return 200 on profile update")
    @WithMockUser(roles = "PASSENGER")
    void updateUserProfile_Success_Returns200() throws Exception {
        UserDto.UpdateProfileRequest updateRequest = new UserDto.UpdateProfileRequest("Joseph", "Smith", null);
        when(userService.updateUserProfile(eq(1L), any())).thenReturn(userResponse);

        mockMvc.perform(put("/api/users/1")
                        .with(csrf())
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(updateRequest)))
                .andExpect(status().isOk());
    }
}
