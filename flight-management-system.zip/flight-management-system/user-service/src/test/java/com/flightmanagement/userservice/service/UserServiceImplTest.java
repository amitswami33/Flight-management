package com.flightmanagement.userservice.service;

import com.flightmanagement.userservice.dto.UserDto;
import com.flightmanagement.userservice.entity.User;
import com.flightmanagement.userservice.exception.UserAlreadyExistsException;
import com.flightmanagement.userservice.exception.UserNotFoundException;
import com.flightmanagement.userservice.repository.UserRepository;
import com.flightmanagement.userservice.security.JwtService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Unit tests for UserServiceImpl using Mockito.
 * Tests all service layer business logic in isolation.
 */
@ExtendWith(MockitoExtension.class)
class UserServiceImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtService jwtService;

    @Mock
    private AuthenticationManager authenticationManager;

    @Mock
    private UserDetailsService userDetailsService;

    @InjectMocks
    private UserServiceImpl userService;

    private User mockUser;
    private UserDto.RegisterRequest registerRequest;
    private UserDto.LoginRequest loginRequest;

    @BeforeEach
    void setUp() {
        mockUser = new User();
        mockUser.setUserId(1L);
        mockUser.setFirstName("Joe");
        mockUser.setLastName("Doe");
        mockUser.setEmail("joe@example.com");
        mockUser.setPassword("encodedPassword");
        mockUser.setPhoneNumber("9876543210");
        mockUser.setRole(User.Role.PASSENGER);
        mockUser.setActive(true);

        registerRequest = new UserDto.RegisterRequest();
        registerRequest.setFirstName("Joe");
        registerRequest.setLastName("Doe");
        registerRequest.setEmail("joe@example.com");
        registerRequest.setPassword("password123");
        registerRequest.setPhoneNumber("9876543210");

        loginRequest = new UserDto.LoginRequest();
        loginRequest.setEmail("joe@example.com");
        loginRequest.setPassword("password123");
    }

    @Test
    @DisplayName("Should register user successfully when email is not taken")
    void registerUser_Success() {
        // Arrange
        when(userRepository.existsByEmail(anyString())).thenReturn(false);
        when(passwordEncoder.encode(anyString())).thenReturn("encodedPassword");
        when(userRepository.save(any(User.class))).thenReturn(mockUser);

        org.springframework.security.core.userdetails.User springUser =
                new org.springframework.security.core.userdetails.User(
                        "joe@example.com", "encodedPassword", java.util.Collections.emptyList());
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(springUser);
        when(jwtService.generateToken(any(), anyString())).thenReturn("mock-jwt-token");

        // Act
        UserDto.AuthResponse response = userService.registerUser(registerRequest);

        // Assert
        assertNotNull(response);
        assertEquals("mock-jwt-token", response.getToken());
        assertEquals("joe@example.com", response.getEmail());
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    @DisplayName("Should throw UserAlreadyExistsException when email is already registered")
    void registerUser_EmailAlreadyExists_ThrowsException() {
        // Arrange
        when(userRepository.existsByEmail("joe@example.com")).thenReturn(true);

        // Act & Assert
        assertThrows(UserAlreadyExistsException.class,
                () -> userService.registerUser(registerRequest));
        verify(userRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should login user successfully with valid credentials")
    void loginUser_Success() {
        // Arrange
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(null);
        when(userRepository.findByEmail("joe@example.com")).thenReturn(Optional.of(mockUser));

        org.springframework.security.core.userdetails.User springUser =
                new org.springframework.security.core.userdetails.User(
                        "joe@example.com", "encodedPassword", java.util.Collections.emptyList());
        when(userDetailsService.loadUserByUsername(anyString())).thenReturn(springUser);
        when(jwtService.generateToken(any(), anyString())).thenReturn("mock-jwt-token");

        // Act
        UserDto.AuthResponse response = userService.loginUser(loginRequest);

        // Assert
        assertNotNull(response);
        assertEquals("mock-jwt-token", response.getToken());
        assertEquals(1L, response.getUserId());
    }

    @Test
    @DisplayName("Should return user by ID when found")
    void getUserById_Found() {
        // Arrange
        when(userRepository.findById(1L)).thenReturn(Optional.of(mockUser));

        // Act
        UserDto.UserResponse response = userService.getUserById(1L);

        // Assert
        assertNotNull(response);
        assertEquals(1L, response.getUserId());
        assertEquals("Joe", response.getFirstName());
        assertEquals("joe@example.com", response.getEmail());
    }

    @Test
    @DisplayName("Should throw UserNotFoundException when user ID not found")
    void getUserById_NotFound_ThrowsException() {
        // Arrange
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(UserNotFoundException.class, () -> userService.getUserById(99L));
    }

    @Test
    @DisplayName("Should update user profile successfully")
    void updateUserProfile_Success() {
        // Arrange
        UserDto.UpdateProfileRequest updateRequest = new UserDto.UpdateProfileRequest();
        updateRequest.setFirstName("Joseph");
        updateRequest.setLastName("Smith");

        when(userRepository.findById(1L)).thenReturn(Optional.of(mockUser));
        when(userRepository.save(any(User.class))).thenReturn(mockUser);

        // Act
        UserDto.UserResponse response = userService.updateUserProfile(1L, updateRequest);

        // Assert
        assertNotNull(response);
        verify(userRepository, times(1)).save(any(User.class));
    }

    @Test
    @DisplayName("Should deactivate user successfully")
    void deactivateUser_Success() {
        // Arrange
        when(userRepository.findById(1L)).thenReturn(Optional.of(mockUser));
        when(userRepository.save(any(User.class))).thenReturn(mockUser);

        // Act
        userService.deactivateUser(1L);

        // Assert
        assertFalse(mockUser.isActive());
        verify(userRepository, times(1)).save(mockUser);
    }

    @Test
    @DisplayName("Should throw UserNotFoundException when deactivating non-existent user")
    void deactivateUser_NotFound_ThrowsException() {
        // Arrange
        when(userRepository.findById(99L)).thenReturn(Optional.empty());

        // Act & Assert
        assertThrows(UserNotFoundException.class, () -> userService.deactivateUser(99L));
    }
}
