
# Flight Management System (Microservices)

**Tech stack**: Spring Boot 3 (Java 17), Spring Cloud (Eureka, Gateway, LoadBalancer, OpenFeign), Spring Security (JWT), JPA/Hibernate, MySQL, RabbitMQ, SLF4J/Logback, springdoc-openapi (Swagger), JUnit5/Mockito.

## Modules
- `discovery-server`: Eureka server
- `api-gateway`: Spring Cloud Gateway + JWT auth
- `user-service`: Authentication/Authorization (JWT issue/validate), roles USER/ADMIN
- `flight-service`: Manage/search flights
- `booking-service`: Create booking, confirm after payment, publishes events to RabbitMQ
- `payment-service`: Razorpay integration (create order, webhook callback)
- `checkin-service`: Check-in and boarding pass
- `notification-service`: Consumer of booking events (RabbitMQ)
- `common-lib`: Shared DTOs, exceptions, constants

## Quick start
1. Install Java 17 and Maven.
2. Start infra with Docker (MySQL & RabbitMQ):
   ```bash
   docker compose up -d
   ```
3. Build all modules:
   ```bash
   mvn -q -DskipTests clean package
   ```
4. Run services (in separate terminals):
   ```bash
   # order matters: discovery -> gateway -> others
   (cd discovery-server && mvn spring-boot:run)
   (cd api-gateway && mvn spring-boot:run)
   (cd user-service && mvn spring-boot:run)
   (cd flight-service && mvn spring-boot:run)
   (cd payment-service && mvn spring-boot:run)
   (cd booking-service && mvn spring-boot:run)
   (cd checkin-service && mvn spring-boot:run)
   (cd notification-service && mvn spring-boot:run)
   ```

5. Open Swagger UIs:
   - Gateway routes Swagger UIs from each service: `http://localhost:8080/swagger-ui.html`

6. Import Postman collection: `postman/FMS.postman_collection.json`.

> **Razorpay**: set `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` environment variables (or in `payment-service` `application.yml`). If not set, the payment service falls back to a sandbox stub.

## Default credentials
- Admin: `admin@fms.com` / `admin123`
- User:  `user@fms.com`  / `user123`

## Notes
- JWT secret is in `.env.example` for local dev. **Change in prod**.
- All services register with Eureka and are discoverable.
- Inter-service sync calls use OpenFeign; async events use RabbitMQ.

