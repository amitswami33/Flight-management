package com.fms.booking.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "payment-service")
public interface PaymentClient {

    @PostMapping("/api/payments/create-order")
    String createOrder(@RequestParam("bookingId") Long bookingId,
                       @RequestParam("amount") Double amount);
}