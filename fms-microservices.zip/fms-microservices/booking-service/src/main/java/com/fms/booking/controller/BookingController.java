
package com.fms.booking.controller;

import com.fms.booking.client.PaymentClient;
import com.fms.booking.entity.Booking;
import com.fms.booking.repo.BookingRepository;
import com.fms.booking.mq.BookingPublisher;
import com.fms.common.dto.BookingEvent;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/bookings")
public class BookingController {
    private final BookingRepository repo;
    private final PaymentClient paymentClient;
    private final BookingPublisher publisher;

    public BookingController(BookingRepository repo, PaymentClient paymentClient, BookingPublisher publisher) {
        this.repo = repo; this.paymentClient = paymentClient; this.publisher = publisher;
    }

    @PostMapping
    public ResponseEntity<Booking> create(@Valid @RequestBody Booking b){
        b.setStatus("CREATED");
        Booking saved = repo.save(b);
        // create payment order (dummy amount)
        paymentClient.createOrder(saved.getId(), 5000.0);
        publisher.publish(BookingEvent.builder().bookingId(saved.getId()).flightId(saved.getFlightId()).userId(saved.getUserId()).status("CREATED").build());
        return ResponseEntity.ok(saved);
    }

    @PostMapping("/{id}/confirm")
    public ResponseEntity<Booking> confirm(@PathVariable Long id){
        var b = repo.findById(id).orElseThrow(() -> new RuntimeException("Booking not found"));
        b.setStatus("CONFIRMED");
        repo.save(b);
        publisher.publish(BookingEvent.builder().bookingId(b.getId()).flightId(b.getFlightId()).userId(b.getUserId()).status("CONFIRMED").build());
        return ResponseEntity.ok(b);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Booking> get(@PathVariable Long id){
        return ResponseEntity.of(repo.findById(id));
    }
}
