
package com.fms.booking.mq;

import com.fms.common.dto.BookingEvent;
import org.springframework.amqp.core.TopicExchange;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Component;

@Component
public class BookingPublisher {
    private final RabbitTemplate rabbitTemplate;
    private final TopicExchange exchange;

    public BookingPublisher(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
        this.exchange = new TopicExchange("booking.exchange");
    }

    public void publish(BookingEvent event){
        rabbitTemplate.convertAndSend(exchange.getName(), "booking.status", event);
    }
}
