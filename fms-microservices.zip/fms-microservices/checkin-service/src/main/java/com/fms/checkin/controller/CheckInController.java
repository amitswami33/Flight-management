
package com.fms.checkin.controller;

import com.fms.checkin.entity.CheckIn;
import com.fms.checkin.repo.CheckInRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/checkin")
public class CheckInController {
    private final CheckInRepository repo;
    public CheckInController(CheckInRepository repo){ this.repo = repo; }

    @PostMapping
    public ResponseEntity<CheckIn> checkIn(@RequestParam Long bookingId){
        CheckIn c = CheckIn.builder().bookingId(bookingId).status("CHECKED_IN").time(String.valueOf(System.currentTimeMillis())).build();
        return ResponseEntity.ok(repo.save(c));
    }
}
