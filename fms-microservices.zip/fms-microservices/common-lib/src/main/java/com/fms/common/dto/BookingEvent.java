
package com.fms.common.dto;

import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BookingEvent {
    private Long bookingId;
    private Long userId;
    private Long flightId;
    private String status; // CREATED, CONFIRMED, CANCELLED
}
