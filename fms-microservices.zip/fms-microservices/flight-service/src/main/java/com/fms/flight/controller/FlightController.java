
package com.fms.flight.controller;

import com.fms.flight.entity.Flight;
import com.fms.flight.repo.FlightRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/flights")
public class FlightController {
    private final FlightRepository repo;
    public FlightController(FlightRepository repo){this.repo = repo;}

    @GetMapping
    public ResponseEntity<List<Flight>> search(@RequestParam String source, @RequestParam String destination){
        return ResponseEntity.ok(repo.findBySourceAndDestination(source, destination));
    }

    @PostMapping
    public ResponseEntity<Flight> create(@Valid @RequestBody Flight f){
        return ResponseEntity.ok(repo.save(f));
    }
}
