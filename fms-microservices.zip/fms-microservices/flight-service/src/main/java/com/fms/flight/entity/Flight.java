
package com.fms.flight.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Data @NoArgsConstructor @AllArgsConstructor @Builder
public class Flight {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @NotBlank private String flightNumber;
    @NotBlank private String source;
    @NotBlank private String destination;
    @NotBlank private String departureTime; // simplify
    private int seatsAvailable;
}
