
package com.fms.flight;

import com.fms.flight.controller.FlightController;
import com.fms.flight.entity.Flight;
import com.fms.flight.repo.FlightRepository;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.http.ResponseEntity;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class FlightControllerTests {
    @Test
    void search_returns_list(){
        FlightRepository repo = Mockito.mock(FlightRepository.class);
        Mockito.when(repo.findBySourceAndDestination("MUM","DEL")).thenReturn(List.of(Flight.builder().id(1L).flightNumber("AI-101").source("MUM").destination("DEL").departureTime("10:00").seatsAvailable(10).build()));
        FlightController c = new FlightController(repo);
        ResponseEntity<List<Flight>> res = c.search("MUM","DEL");
        assertEquals(1, res.getBody().size());
    }
}
