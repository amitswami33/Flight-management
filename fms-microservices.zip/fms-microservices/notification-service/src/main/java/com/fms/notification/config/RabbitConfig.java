
package com.fms.notification.config;

import org.springframework.amqp.core.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {
    @Bean
    public TopicExchange bookingExchange(){ return new TopicExchange("booking.exchange"); }
    @Bean
    public Queue bookingQueue(){ return new Queue("booking.notifications", true); }
    @Bean
    public Binding binding(){ return BindingBuilder.bind(bookingQueue()).to(bookingExchange()).with("booking.status"); }
}
