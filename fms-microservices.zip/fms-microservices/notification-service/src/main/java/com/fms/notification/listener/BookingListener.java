
package com.fms.notification.listener;

import com.fms.common.dto.BookingEvent;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

@Component
public class BookingListener {
    @RabbitListener(queues = "booking.notifications")
    public void onEvent(BookingEvent event){
        System.out.println("[Notification] Booking event received: "+event);
        // Here send Email/SMS etc.
    }
}
