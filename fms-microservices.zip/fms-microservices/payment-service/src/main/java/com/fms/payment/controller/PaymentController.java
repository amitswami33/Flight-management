
package com.fms.payment.controller;

import com.fms.payment.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {
    private final PaymentService service;
    public PaymentController(PaymentService service){ this.service = service; }

    @PostMapping("/create-order")
    public ResponseEntity<String> createOrder(@RequestParam Long bookingId, @RequestParam Double amount){
        return ResponseEntity.ok(service.createOrder(bookingId, amount));
    }

    @PostMapping("/webhook")
    public ResponseEntity<String> webhook(@RequestBody String payload, @RequestHeader(name="X-Razorpay-Signature", required=false) String signature) {
        service.handleWebhook(payload, signature);
        return ResponseEntity.ok("ok");
    }
}
