
package com.fms.payment.service;

import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {
    @Value("${razorpay.key-id:}")
    private String keyId;
    @Value("${razorpay.key-secret:}")
    private String keySecret;

    public String createOrder(Long bookingId, Double amount){
        try {
            if(keyId==null || keyId.isBlank()){
                // Fallback stub for local dev
                return "ORDER_LOCAL_"+bookingId;
            }
            RazorpayClient client = new RazorpayClient(keyId, keySecret);
            JSONObject orderRequest = new JSONObject();
            orderRequest.put("amount", Math.round(amount*100)); // paise
            orderRequest.put("currency", "INR");
            orderRequest.put("receipt", "rcpt_"+bookingId);
            Order order = client.orders.create(orderRequest);
            return order.get("id");
        } catch (Exception e){
            throw new RuntimeException("Payment order creation failed: "+e.getMessage());
        }
    }

    public void handleWebhook(String payload, String signature){
        // In real impl, verify signature & update Booking by calling booking-service
        // For brevity, just log payload
        System.out.println("Webhook payload: "+payload);
    }
}
