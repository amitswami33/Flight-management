
package com.fms.user.config;

import com.fms.user.entity.User;
import com.fms.user.repo.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
public class DataInitConfig {
    @Bean
    CommandLineRunner init(UserRepository repo, PasswordEncoder encoder){
        return args -> {
            repo.findByEmail("admin@fms.com").orElseGet(() ->
                repo.save(User.builder().name("Admin").email("admin@fms.com").password(encoder.encode("admin123")).role("ADMIN").build())
            );
            repo.findByEmail("user@fms.com").orElseGet(() ->
                repo.save(User.builder().name("User").email("user@fms.com").password(encoder.encode("user123")).role("USER").build())
            );
        };
    }
}
