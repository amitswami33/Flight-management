
package com.fms.user.controller;

import com.fms.common.dto.AuthRequest;
import com.fms.common.dto.AuthResponse;
import com.fms.user.entity.User;
import com.fms.user.service.JwtService;
import com.fms.user.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class AuthController {
    private final UserService userService;
    private final JwtService jwtService;

    public AuthController(UserService userService, JwtService jwtService) {
        this.userService = userService;
        this.jwtService = jwtService;
    }

    @PostMapping("/register")
    public ResponseEntity<User> register(@Valid @RequestBody User u){
        return ResponseEntity.ok(userService.register(u));
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody AuthRequest req){
        var user = userService.findByEmail(req.getEmail()).orElseThrow(() -> new RuntimeException("User not found"));
        if(!userService.matches(req.getPassword(), user.getPassword()))
            throw new RuntimeException("Invalid credentials");
        String token = jwtService.generateToken(user.getEmail(), Map.of("role", user.getRole(), "userId", user.getId()));
        return ResponseEntity.ok(new AuthResponse(token));
    }
}
