
package com.fms.user.service;

import com.fms.user.entity.User;
import com.fms.user.repo.UserRepository;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {
    private final UserRepository repo;
    private final PasswordEncoder encoder = new BCryptPasswordEncoder();

    public UserService(UserRepository repo) { this.repo = repo; }

    public User register(User u){
        repo.findByEmail(u.getEmail()).ifPresent(x -> { throw new RuntimeException("User already exists"); });
        u.setPassword(encoder.encode(u.getPassword()));
        if(u.getRole()==null||u.getRole().isBlank()) u.setRole("USER");
        return repo.save(u);
    }

    public Optional<User> findByEmail(String email){ return repo.findByEmail(email);}    
    public boolean matches(String raw, String hash){ return encoder.matches(raw, hash);}    
}
