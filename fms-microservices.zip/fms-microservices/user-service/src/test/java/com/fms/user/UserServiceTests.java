
package com.fms.user;

import com.fms.user.entity.User;
import com.fms.user.repo.UserRepository;
import com.fms.user.service.UserService;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;

public class UserServiceTests {
    @Test
    void register_hashes_password(){
        UserRepository repo = Mockito.mock(UserRepository.class);
        Mockito.when(repo.findByEmail("a@b.com")).thenReturn(Optional.empty());
        Mockito.when(repo.save(Mockito.any())).thenAnswer(i->i.getArgument(0));
        UserService svc = new UserService(repo);
        User u = User.builder().name("A").email("a@b.com").password("pass").role("USER").build();
        User saved = svc.register(u);
        assertNotEquals("pass", saved.getPassword());
    }
}
